# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError, UserError
from datetime import datetime
from unittest.mock import patch, MagicMock
import base64


class TestMailProcessing(TransactionCase):
    """Tests pour le modèle MailProcessing"""
    
    def setUp(self):
        super().setUp()
        
        # Créer un dossier de test
        self.test_folder = self.env['documents.folder'].create({
            'name': 'Test Email Folder',
            'description': 'Dossier de test pour les emails'
        })
        
        # Créer un partenaire de test
        self.test_partner = self.env['res.partner'].create({
            'name': 'Test Partner',
            'email': 'test@example.com'
        })
        
        # Créer un traitement email de test
        self.mail_processing = self.env['afrik.lonnya.mail.processing'].create({
            'subject': 'Test Email Subject',
            'sender_email': 'sender@test.com',
            'recipient_email': 'recipient@test.com',
            'processing_type': 'incoming',
            'body_html': '<p>Test email body</p>',
            'body_text': 'Test email body',
            'message_id': 'test-message-id@test.com',
            'date_received': datetime.now(),
            'folder_id': self.test_folder.id
        })
    
    def test_mail_processing_creation(self):
        """Test de création d'un traitement email"""
        self.assertTrue(self.mail_processing.id)
        self.assertEqual(self.mail_processing.subject, 'Test Email Subject')
        self.assertEqual(self.mail_processing.processing_type, 'incoming')
        self.assertEqual(self.mail_processing.state, 'draft')
    
    def test_mail_direction_computation(self):
        """Test du calcul de la direction"""
        # Test email entrant
        self.mail_processing.write({'processing_type': 'incoming'})
        self.mail_processing._compute_direction()
        self.assertEqual(self.mail_processing.direction, 'in')
        
        # Test email sortant
        self.mail_processing.write({'processing_type': 'outgoing'})
        self.mail_processing._compute_direction()
        self.assertEqual(self.mail_processing.direction, 'out')
    
    def test_mail_processing_with_attachments(self):
        """Test de traitement avec pièces jointes"""
        # Créer une pièce jointe de test
        attachment_data = base64.b64encode(b'Test file content')
        attachment = self.env['ir.attachment'].create({
            'name': 'test_file.pdf',
            'datas': attachment_data,
            'mimetype': 'application/pdf',
            'res_model': 'afrik.lonnya.mail.processing',
            'res_id': self.mail_processing.id
        })
        
        # Vérifier le calcul du nombre de pièces jointes
        self.mail_processing._compute_attachment_count()
        self.assertEqual(self.mail_processing.attachment_count, 1)
    
    def test_mail_processing_action_process(self):
        """Test de l'action de traitement"""
        # Traiter l'email
        self.mail_processing.action_process()
        
        # Vérifier que l'état a changé
        self.assertEqual(self.mail_processing.state, 'processed')
        self.assertTrue(self.mail_processing.processing_date)
    
    def test_mail_processing_create_document_from_attachment(self):
        """Test de création de document depuis une pièce jointe"""
        # Créer une pièce jointe
        attachment_data = base64.b64encode(b'Test PDF content')
        attachment = self.env['ir.attachment'].create({
            'name': 'document_test.pdf',
            'datas': attachment_data,
            'mimetype': 'application/pdf'
        })
        
        # Créer un document depuis la pièce jointe
        document = self.mail_processing._create_document_from_attachment(
            attachment, self.test_folder.id
        )
        
        self.assertTrue(document.id)
        self.assertEqual(document.name, 'document_test.pdf')
        self.assertEqual(document.folder_id, self.test_folder)
    
    def test_mail_processing_validation(self):
        """Test de validation des données"""
        # Test email invalide
        with self.assertRaises(ValidationError):
            self.mail_processing.write({'sender_email': 'invalid-email'})
    
    def test_mail_processing_retry(self):
        """Test de nouvelle tentative de traitement"""
        # Marquer comme échoué
        self.mail_processing.write({'state': 'failed'})
        
        # Réessayer
        self.mail_processing.action_retry()
        
        # Vérifier que l'état est revenu à draft
        self.assertEqual(self.mail_processing.state, 'draft')