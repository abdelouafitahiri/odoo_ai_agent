# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta


class TestCommunicationLog(TransactionCase):
    """Tests pour le modèle CommunicationLog"""
    
    def setUp(self):
        super().setUp()
        
        # Créer un document de test
        self.test_folder = self.env['documents.folder'].create({
            'name': 'Test Folder',
            'description': 'Dossier de test'
        })
        
        self.document = self.env['documents.document'].create({
            'name': 'Document Test',
            'folder_id': self.test_folder.id,
            'mimetype': 'application/pdf'
        })
        
        # Créer un partenaire de test
        self.partner = self.env['res.partner'].create({
            'name': 'Test Partner',
            'email': 'partner@test.com'
        })
        
        # Créer un log de communication
        self.comm_log = self.env['afrik.lonnya.communication.log'].create({
            'communication_type': 'email',
            'direction': 'outgoing',
            'log_type': 'info',
            'message': 'Test communication message',
            'document_id': self.document.id,
            'partner_id': self.partner.id,
            'priority': 'medium'
        })
    
    def test_communication_log_creation(self):
        """Test de création d'un log de communication"""
        self.assertTrue(self.comm_log.id)
        self.assertEqual(self.comm_log.communication_type, 'email')
        self.assertEqual(self.comm_log.direction, 'outgoing')
        self.assertEqual(self.comm_log.state, 'active')
    
    def test_communication_log_computed_fields(self):
        """Test des champs calculés"""
        # Test du calcul de l'âge
        self.comm_log._compute_age_days()
        self.assertEqual(self.comm_log.age_days, 0)  # Créé aujourd'hui
        
        # Test du calcul is_recent
        self.comm_log._compute_is_recent()
        self.assertTrue(self.comm_log.is_recent)  # Créé aujourd'hui
    
    def test_communication_log_display_name(self):
        """Test du nom d'affichage"""
        self.comm_log._compute_display_name()
        expected_name = f"[{self.comm_log.communication_type.upper()}] Test communication message"
        self.assertEqual(self.comm_log.display_name, expected_name)
    
    def test_communication_log_mark_as_viewed(self):
        """Test de marquage comme vu"""
        self.comm_log.action_mark_as_viewed()
        self.assertTrue(self.comm_log.is_viewed)
        self.assertTrue(self.comm_log.viewed_date)
    
    def test_communication_log_archive(self):
        """Test d'archivage"""
        self.comm_log.action_archive()
        self.assertEqual(self.comm_log.state, 'archived')
        
        # Test de désarchivage
        self.comm_log.action_unarchive()
        self.assertEqual(self.comm_log.state, 'active')
    
    def test_communication_log_create_follow_up(self):
        """Test de création de suivi"""
        follow_up = self.comm_log.action_create_follow_up()
        
        self.assertTrue(follow_up.id)
        self.assertEqual(follow_up.parent_log_id, self.comm_log)
        self.assertEqual(follow_up.document_id, self.comm_log.document_id)
    
    def test_communication_log_cleanup(self):
        """Test du nettoyage des anciens logs"""
        # Créer un log ancien
        old_log = self.env['afrik.lonnya.communication.log'].create({
            'communication_type': 'email',
            'direction': 'incoming',
            'log_type': 'info',
            'message': 'Old log message',
            'create_date': datetime.now() - timedelta(days=100)
        })
        
        # Exécuter le nettoyage (90 jours par défaut)
        self.env['afrik.lonnya.communication.log'].cleanup_old_logs(90)
        
        # Vérifier que l'ancien log est archivé
        old_log.refresh()
        self.assertEqual(old_log.state, 'archived')