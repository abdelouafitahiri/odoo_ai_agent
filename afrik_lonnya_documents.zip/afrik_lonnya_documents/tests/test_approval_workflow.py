# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta
from unittest.mock import patch


class TestApprovalWorkflow(TransactionCase):
    """Tests pour le modèle ApprovalWorkflow"""
    
    def setUp(self):
        super().setUp()
        
        # Créer des utilisateurs de test
        self.user_manager = self.env['res.users'].create({
            'name': 'Manager Test',
            'login': 'manager@test.com',
            'email': 'manager@test.com',
            'groups_id': [(6, 0, [self.env.ref('base.group_user').id])]
        })
        
        self.user_approver = self.env['res.users'].create({
            'name': 'Approver Test',
            'login': 'approver@test.com',
            'email': 'approver@test.com',
            'groups_id': [(6, 0, [self.env.ref('base.group_user').id])]
        })
        
        # Créer un dossier de test
        self.test_folder = self.env['documents.folder'].create({
            'name': 'Test Folder',
            'description': 'Dossier de test pour les workflows'
        })
        
        # Créer un workflow de test
        self.workflow = self.env['afrik.lonnya.approval.workflow'].create({
            'name': 'Workflow Test',
            'code': 'WF_TEST',
            'workflow_type': 'sequential',
            'description': 'Workflow de test pour les documents',
            'is_active': True,
            'auto_start': True,
            'notification_on_start': True,
            'notification_on_complete': True,
            'max_duration_days': 7,
            'reminder_days': 3
        })
    
    def test_workflow_creation(self):
        """Test de création d'un workflow"""
        self.assertTrue(self.workflow.id)
        self.assertEqual(self.workflow.name, 'Workflow Test')
        self.assertEqual(self.workflow.code, 'WF_TEST')
        self.assertEqual(self.workflow.workflow_type, 'sequential')
        self.assertTrue(self.workflow.is_active)
    
    def test_workflow_code_uniqueness(self):
        """Test de l'unicité du code de workflow"""
        with self.assertRaises(ValidationError):
            self.env['afrik.lonnya.approval.workflow'].create({
                'name': 'Workflow Test 2',
                'code': 'WF_TEST',  # Code déjà utilisé
                'workflow_type': 'sequential'
            })
    
    def test_workflow_computed_fields(self):
        """Test des champs calculés"""
        self.assertEqual(self.workflow.step_count, 0)  # Pas d'étapes créées dans ce test
        self.assertEqual(self.workflow.document_count, 0)
    
    def test_workflow_validation(self):
        """Test de validation des données"""
        with self.assertRaises(ValidationError):
            self.workflow.write({'max_duration_days': 0})