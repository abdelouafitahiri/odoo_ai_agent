# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta


class TestDocumentExtension(TransactionCase):
    """Tests pour l'extension du modèle Document"""
    
    def setUp(self):
        super().setUp()
        
        # Créer un type de document
        self.document_type = self.env['afrik.lonnya.document.type'].create({
            'name': 'Type Test',
            'code': 'TEST_TYPE',
            'category': 'administrative',
            'description': 'Type de document de test'
        })
        
        # Créer un dossier
        self.test_folder = self.env['documents.folder'].create({
            'name': 'Test Folder',
            'description': 'Dossier de test'
        })
        
        # Créer un document de test
        self.document = self.env['documents.document'].create({
            'name': 'Document Test',
            'folder_id': self.test_folder.id,
            'mimetype': 'application/pdf',
            'afrik_lonnya_document_type_id': self.document_type.id,
            'afrik_lonnya_reference_number': 'DOC-2024-001',
            'afrik_lonnya_classification_level': 'internal',
            'afrik_lonnya_expiry_date': datetime.now() + timedelta(days=30)
        })
    
    def test_document_creation_with_extensions(self):
        """Test de création de document avec extensions"""
        self.assertTrue(self.document.id)
        self.assertEqual(self.document.afrik_lonnya_reference_number, 'DOC-2024-001')
        self.assertEqual(self.document.afrik_lonnya_classification_level, 'internal')
        self.assertEqual(self.document.afrik_lonnya_approval_status, 'draft')
    
    def test_document_expiry_computation(self):
        """Test du calcul de l'expiration"""
        # Document qui expire dans 30 jours
        self.document._compute_days_until_expiry()
        self.assertAlmostEqual(self.document.afrik_lonnya_days_until_expiry, 30, delta=1)
        self.assertFalse(self.document.afrik_lonnya_is_expired)
        
        # Document expiré
        self.document.write({
            'afrik_lonnya_expiry_date': datetime.now() - timedelta(days=1)
        })
        self.document._compute_days_until_expiry()
        self.assertTrue(self.document.afrik_lonnya_is_expired)
    
    def test_document_approval_workflow(self):
        """Test du workflow d'approbation"""
        # Approuver le document
        self.document.action_approve()
        self.assertEqual(self.document.afrik_lonnya_approval_status, 'approved')
        self.assertTrue(self.document.afrik_lonnya_approval_date)
        
        # Rejeter le document
        self.document.action_reject()
        self.assertEqual(self.document.afrik_lonnya_approval_status, 'rejected')
    
    def test_document_archiving(self):
        """Test de l'archivage de document"""
        self.document.action_archive_document()
        self.assertEqual(self.document.afrik_lonnya_approval_status, 'archived')
        self.assertTrue(self.document.afrik_lonnya_archive_date)
    
    def test_document_versioning(self):
        """Test du versioning"""
        # Créer une nouvelle version
        new_version = self.document.action_create_version()
        
        self.assertTrue(new_version.id)
        self.assertNotEqual(new_version.id, self.document.id)
        self.assertEqual(new_version.afrik_lonnya_parent_document_id, self.document)
        self.assertEqual(new_version.afrik_lonnya_version_number, 2)
    
    def test_document_reference_uniqueness(self):
        """Test de l'unicité de la référence"""
        with self.assertRaises(ValidationError):
            self.env['documents.document'].create({
                'name': 'Document Test 2',
                'folder_id': self.test_folder.id,
                'mimetype': 'application/pdf',
                'afrik_lonnya_reference_number': 'DOC-2024-001'  # Référence déjà utilisée
            })
    
    def test_document_classification_validation(self):
        """Test de validation de la classification"""
        # Classification valide
        valid_classifications = ['public', 'internal', 'confidential', 'secret']
        for classification in valid_classifications:
            self.document.write({'afrik_lonnya_classification_level': classification})
            # Pas d'exception levée
    
    def test_document_expiry_date_validation(self):
        """Test de validation de la date d'expiration"""
        # Date d'expiration dans le passé (devrait être autorisée pour les documents existants)
        past_date = datetime.now() - timedelta(days=1)
        self.document.write({'afrik_lonnya_expiry_date': past_date})
        # Pas d'exception pour les documents existants