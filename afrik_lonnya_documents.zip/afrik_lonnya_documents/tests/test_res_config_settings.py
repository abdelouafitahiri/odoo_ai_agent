# -*- coding: utf-8 -*-

from odoo.tests.common import TransactionCase
from odoo.exceptions import ValidationError


class TestResConfigSettings(TransactionCase):
    """Tests pour les paramètres de configuration"""
    
    def setUp(self):
        super().setUp()
        
        self.config = self.env['res.config.settings'].create({})
    
    def test_config_validation_positive_values(self):
        """Test de validation des valeurs positives"""
        # Test des jours d'archivage automatique
        with self.assertRaises(ValidationError):
            self.config.write({'afrik_lonnya_auto_archive_days': 0})
        
        # Test du nombre maximum de versions
        with self.assertRaises(ValidationError):
            self.config.write({'afrik_lonnya_max_versions': 0})
    
    def test_config_approval_settings_validation(self):
        """Test de validation des paramètres d'approbation"""
        # Test du délai de rappel vs délai d'expiration
        with self.assertRaises(ValidationError):
            self.config.write({
                'afrik_lonnya_approval_timeout_days': 5,
                'afrik_lonnya_approval_reminder_days': 6  # Plus grand que timeout
            })
    
    def test_config_mail_settings_validation(self):
        """Test de validation des paramètres email"""
        # Test de la taille maximale des pièces jointes
        with self.assertRaises(ValidationError):
            self.config.write({'afrik_lonnya_mail_max_attachment_size': 0})
    
    def test_config_reset_to_defaults(self):
        """Test de remise à zéro des paramètres"""
        # Modifier quelques paramètres
        self.config.write({
            'afrik_lonnya_auto_archive_days': 500,
            'afrik_lonnya_max_versions': 20
        })
        
        # Remettre aux valeurs par défaut
        result = self.config.action_reset_to_defaults()
        
        # Vérifier le résultat
        self.assertEqual(result['type'], 'ir.actions.client')
        
        # Vérifier que les valeurs sont revenues aux défauts
        self.config.refresh()
        self.assertEqual(self.config.afrik_lonnya_auto_archive_days, 365)
        self.assertEqual(self.config.afrik_lonnya_max_versions, 10)
    
    def test_config_create_default_folder(self):
        """Test de création du dossier par défaut"""
        result = self.config.action_create_default_folder()
        
        self.assertEqual(result['type'], 'ir.actions.client')
        
        # Vérifier que le dossier a été créé
        folder = self.env['documents.folder'].search([('name', '=', 'Emails')], limit=1)
        self.assertTrue(folder.id)