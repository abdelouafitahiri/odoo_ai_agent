# -*- coding: utf-8 -*-

# Test modules imports
from . import test_document_extension
from . import test_incoming_mail
from . import test_outgoing_mail
from . import test_contract_document
from . import test_approval_workflow