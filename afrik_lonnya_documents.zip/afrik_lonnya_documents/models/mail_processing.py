# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import re
import email
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import base64


class MailProcessing(models.Model):
    """Modèle pour le traitement des emails entrants et sortants"""
    _name = 'al.mail.processing'
    _description = 'Traitement des Emails'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'
    
    name = fields.Char(
        string='Référence',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('Nouveau'),
        help='Référence unique du traitement d\'email'
    )
    
    # Type et direction
    processing_type = fields.Selection([
        ('incoming', 'Email Entrant'),
        ('outgoing', 'Email Sortant'),
        ('internal', 'Email Interne')
    ], string='Type de Traitement', required=True, default='incoming')
    
    direction = fields.Selection([
        ('in', 'Entrant'),
        ('out', 'Sortant')
    ], string='Direction', compute='_compute_direction', store=True)
    
    # État du traitement
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('processing', 'En Traitement'),
        ('processed', 'Traité'),
        ('error', 'Erreur'),
        ('cancelled', 'Annulé')
    ], string='État', default='draft', tracking=True, required=True)
    
    # Informations de l'email
    email_from = fields.Char(
        string='De',
        help='Adresse email de l\'expéditeur'
    )
    
    email_to = fields.Char(
        string='À',
        help='Adresse(s) email du/des destinataire(s)'
    )
    
    email_cc = fields.Char(
        string='CC',
        help='Adresse(s) email en copie'
    )
    
    email_bcc = fields.Char(
        string='BCC',
        help='Adresse(s) email en copie cachée'
    )
    
    subject = fields.Char(
        string='Sujet',
        help='Sujet de l\'email'
    )
    
    body_html = fields.Html(
        string='Corps HTML',
        help='Corps de l\'email en HTML'
    )
    
    body_text = fields.Text(
        string='Corps Texte',
        help='Corps de l\'email en texte brut'
    )
    
    # Métadonnées de l'email
    message_id = fields.Char(
        string='ID du Message',
        help='Identifiant unique du message email'
    )
    
    in_reply_to = fields.Char(
        string='En Réponse À',
        help='ID du message auquel cet email répond'
    )
    
    references = fields.Text(
        string='Références',
        help='Références des messages précédents'
    )
    
    email_date = fields.Datetime(
        string='Date de l\'Email',
        help='Date et heure de l\'email'
    )
    
    # Traitement et classification
    priority = fields.Selection([
        ('0', 'Normale'),
        ('1', 'Élevée'),
        ('2', 'Urgente')
    ], string='Priorité', default='0')
    
    classification = fields.Selection([
        ('public', 'Public'),
        ('internal', 'Interne'),
        ('confidential', 'Confidentiel'),
        ('secret', 'Secret')
    ], string='Classification', default='internal')
    
    # Règles de traitement
    processing_rule_id = fields.Many2one(
        'al.mail.rule',
        string='Règle de Traitement',
        help='Règle appliquée pour traiter cet email'
    )
    
    auto_processed = fields.Boolean(
        string='Traité Automatiquement',
        default=False,
        help='Indique si l\'email a été traité automatiquement'
    )
    
    # Relations avec les documents
    document_ids = fields.Many2many(
        'documents.document',
        string='Documents Associés',
        help='Documents créés ou associés à partir de cet email'
    )
    
    parent_document_id = fields.Many2one(
        'documents.document',
        string='Document Parent',
        help='Document parent si cet email est une réponse'
    )
    
    # Pièces jointes
    attachment_ids = fields.One2many(
        'ir.attachment',
        'res_id',
        domain=[('res_model', '=', 'al.mail.processing')],
        string='Pièces Jointes',
        help='Pièces jointes de l\'email'
    )
    
    attachment_count = fields.Integer(
        string='Nombre de Pièces Jointes',
        compute='_compute_attachment_count',
        help='Nombre de pièces jointes'
    )
    
    # Informations de traitement
    processing_date = fields.Datetime(
        string='Date de Traitement',
        help='Date et heure du traitement'
    )
    
    processing_user_id = fields.Many2one(
        'res.users',
        string='Utilisateur de Traitement',
        help='Utilisateur qui a traité l\'email'
    )
    
    processing_notes = fields.Text(
        string='Notes de Traitement',
        help='Notes sur le traitement de l\'email'
    )
    
    error_message = fields.Text(
        string='Message d\'Erreur',
        help='Message d\'erreur en cas de problème de traitement'
    )
    
    # Statistiques
    processing_time = fields.Float(
        string='Temps de Traitement (minutes)',
        help='Temps de traitement en minutes'
    )
    
    # Relations
    communication_log_ids = fields.One2many(
        'al.communication.log',
        'mail_processing_id',
        string='Logs de Communication',
        help='Logs de communication associés'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('name_unique', 'unique(name)', 'La référence du traitement doit être unique.')
    ]
    
    @api.model
    def create(self, vals):
        """Surcharge de create pour générer la référence"""
        if vals.get('name', _('Nouveau')) == _('Nouveau'):
            vals['name'] = self.env['ir.sequence'].next_by_code('al.mail.processing') or _('Nouveau')
        return super().create(vals)
    
    @api.depends('processing_type')
    def _compute_direction(self):
        """Calcule la direction selon le type"""
        for record in self:
            if record.processing_type == 'outgoing':
                record.direction = 'out'
            else:
                record.direction = 'in'
    
    @api.depends('attachment_ids')
    def _compute_attachment_count(self):
        """Calcule le nombre de pièces jointes"""
        for record in self:
            record.attachment_count = len(record.attachment_ids)
    
    def action_process(self):
        """Lance le traitement de l'email"""
        if self.state != 'draft':
            raise UserError(_("Seuls les emails en brouillon peuvent être traités."))
        
        self.write({
            'state': 'processing',
            'processing_date': fields.Datetime.now(),
            'processing_user_id': self.env.user.id,
        })
        
        try:
            # Appliquer les règles de traitement
            self._apply_processing_rules()
            
            # Traiter selon le type
            if self.processing_type == 'incoming':
                self._process_incoming_email()
            elif self.processing_type == 'outgoing':
                self._process_outgoing_email()
            else:
                self._process_internal_email()
            
            # Marquer comme traité
            self.write({
                'state': 'processed',
                'auto_processed': True,
            })
            
            # Créer un log de communication
            self._create_communication_log('processed')
            
        except Exception as e:
            self.write({
                'state': 'error',
                'error_message': str(e),
            })
            
            # Créer un log d'erreur
            self._create_communication_log('error', str(e))
            
            raise UserError(_("Erreur lors du traitement : %s") % str(e))
        
        return True
    
    def _apply_processing_rules(self):
        """Applique les règles de traitement automatique"""
        # Rechercher une règle applicable
        rules = self.env['al.mail.rule'].search([
            ('active', '=', True),
            ('processing_type', '=', self.processing_type)
        ], order='sequence')
        
        for rule in rules:
            if rule.matches_email(self):
                self.processing_rule_id = rule.id
                rule.apply_to_email(self)
                break
    
    def _process_incoming_email(self):
        """Traite un email entrant"""
        # Extraire et traiter les pièces jointes
        documents_created = []
        
        for attachment in self.attachment_ids:
            if self._is_document_attachment(attachment):
                document = self._create_document_from_attachment(attachment)
                if document:
                    documents_created.append(document.id)
        
        # Associer les documents créés
        if documents_created:
            self.document_ids = [(6, 0, documents_created)]
        
        # Créer un document pour l'email lui-même si configuré
        if self.processing_rule_id and self.processing_rule_id.create_email_document:
            email_document = self._create_email_document()
            if email_document:
                self.document_ids = [(4, email_document.id)]
        
        # Rechercher un document parent basé sur les références
        if self.in_reply_to or self.references:
            parent_doc = self._find_parent_document()
            if parent_doc:
                self.parent_document_id = parent_doc.id
    
    def _process_outgoing_email(self):
        """Traite un email sortant"""
        # Logique pour les emails sortants
        # Créer un document de suivi si nécessaire
        if self.processing_rule_id and self.processing_rule_id.create_email_document:
            email_document = self._create_email_document()
            if email_document:
                self.document_ids = [(4, email_document.id)]
    
    def _process_internal_email(self):
        """Traite un email interne"""
        # Logique pour les emails internes
        pass
    
    def _is_document_attachment(self, attachment):
        """Vérifie si une pièce jointe doit être traitée comme document"""
        # Extensions de fichiers à traiter comme documents
        document_extensions = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.txt']
        
        if attachment.name:
            for ext in document_extensions:
                if attachment.name.lower().endswith(ext):
                    return True
        
        return False
    
    def _create_document_from_attachment(self, attachment):
        """Crée un document à partir d'une pièce jointe"""
        try:
            # Déterminer le type de document
            document_type = self._determine_document_type(attachment)
            
            # Créer le document
            document_vals = {
                'name': attachment.name,
                'attachment_id': attachment.id,
                'document_type_id': document_type.id if document_type else False,
                'classification_level': self.classification,
                'source_email': self.email_from,
                'reception_date': self.email_date or fields.Datetime.now(),
                'folder_id': self._get_default_folder().id,
            }
            
            document = self.env['documents.document'].create(document_vals)
            
            # Ajouter des tags si configuré
            if self.processing_rule_id and self.processing_rule_id.tag_ids:
                document.tag_ids = [(6, 0, self.processing_rule_id.tag_ids.ids)]
            
            return document
            
        except Exception as e:
            self.processing_notes = (self.processing_notes or '') + _("\nErreur création document %s: %s") % (attachment.name, str(e))
            return False
    
    def _create_email_document(self):
        """Crée un document pour l'email lui-même"""
        try:
            # Créer un fichier HTML de l'email
            email_content = self._generate_email_html()
            
            # Créer l'attachment
            attachment_vals = {
                'name': f"Email_{self.name}.html",
                'datas': base64.b64encode(email_content.encode('utf-8')),
                'res_model': 'documents.document',
                'mimetype': 'text/html',
            }
            
            attachment = self.env['ir.attachment'].create(attachment_vals)
            
            # Créer le document
            document_vals = {
                'name': f"Email: {self.subject or 'Sans sujet'}",
                'attachment_id': attachment.id,
                'classification_level': self.classification,
                'source_email': self.email_from,
                'reception_date': self.email_date or fields.Datetime.now(),
                'folder_id': self._get_default_folder().id,
            }
            
            document = self.env['documents.document'].create(document_vals)
            attachment.res_id = document.id
            
            return document
            
        except Exception as e:
            self.processing_notes = (self.processing_notes or '') + _("\nErreur création document email: %s") % str(e)
            return False
    
    def _generate_email_html(self):
        """Génère le contenu HTML de l'email"""
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Email: {self.subject or 'Sans sujet'}</title>
        </head>
        <body>
            <div style="font-family: Arial, sans-serif; margin: 20px;">
                <h2>Informations de l'Email</h2>
                <table style="border-collapse: collapse; width: 100%;">
                    <tr><td style="font-weight: bold; padding: 5px;">De:</td><td style="padding: 5px;">{self.email_from or ''}</td></tr>
                    <tr><td style="font-weight: bold; padding: 5px;">À:</td><td style="padding: 5px;">{self.email_to or ''}</td></tr>
                    <tr><td style="font-weight: bold; padding: 5px;">Sujet:</td><td style="padding: 5px;">{self.subject or ''}</td></tr>
                    <tr><td style="font-weight: bold; padding: 5px;">Date:</td><td style="padding: 5px;">{self.email_date or ''}</td></tr>
                </table>
                <hr>
                <h3>Contenu</h3>
                <div>{self.body_html or self.body_text or ''}</div>
            </div>
        </body>
        </html>
        """
        return html_content
    
    def _determine_document_type(self, attachment):
        """Détermine le type de document basé sur l'extension"""
        if not attachment.name:
            return False
        
        # Mapping des extensions vers les types de documents
        extension_mapping = {
            '.pdf': 'PDF',
            '.doc': 'DOC',
            '.docx': 'DOCX',
            '.xls': 'XLS',
            '.xlsx': 'XLSX',
        }
        
        for ext, type_code in extension_mapping.items():
            if attachment.name.lower().endswith(ext):
                doc_type = self.env['al.document.type'].search([
                    ('code', '=', type_code)
                ], limit=1)
                if doc_type:
                    return doc_type
        
        # Type par défaut
        return self.env['al.document.type'].search([
            ('code', '=', 'OTHER')
        ], limit=1)
    
    def _get_default_folder(self):
        """Retourne le dossier par défaut pour les documents"""
        # Rechercher un dossier "Emails" ou créer un dossier par défaut
        folder = self.env['documents.folder'].search([
            ('name', '=', 'Emails')
        ], limit=1)
        
        if not folder:
            # Créer le dossier par défaut
            folder = self.env['documents.folder'].create({
                'name': 'Emails',
                'description': 'Documents créés à partir d\'emails',
            })
        
        return folder
    
    def _find_parent_document(self):
        """Recherche un document parent basé sur les références email"""
        if self.in_reply_to:
            # Rechercher par message_id
            parent_processing = self.search([
                ('message_id', '=', self.in_reply_to)
            ], limit=1)
            
            if parent_processing and parent_processing.document_ids:
                return parent_processing.document_ids[0]
        
        return False
    
    def _create_communication_log(self, log_type, message=None):
        """Crée un log de communication"""
        log_vals = {
            'mail_processing_id': self.id,
            'communication_type': 'email',
            'direction': self.direction,
            'log_type': log_type,
            'message': message or f"Email {log_type}",
            'user_id': self.env.user.id,
        }
        
        return self.env['al.communication.log'].create(log_vals)
    
    def action_retry_processing(self):
        """Relance le traitement en cas d'erreur"""
        if self.state != 'error':
            raise UserError(_("Seuls les emails en erreur peuvent être retraités."))
        
        self.write({
            'state': 'draft',
            'error_message': False,
        })
        
        return self.action_process()
    
    def action_cancel(self):
        """Annule le traitement"""
        if self.state in ['processed']:
            raise UserError(_("Les emails traités ne peuvent pas être annulés."))
        
        self.write({'state': 'cancelled'})
        
        return True
    
    def action_view_documents(self):
        """Action pour voir les documents associés"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Documents Associés'),
            'res_model': 'documents.document',
            'view_mode': 'kanban,tree,form',
            'domain': [('id', 'in', self.document_ids.ids)],
            'context': {'default_folder_id': self._get_default_folder().id},
        }
    
    def action_view_attachments(self):
        """Action pour voir les pièces jointes"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Pièces Jointes'),
            'res_model': 'ir.attachment',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.attachment_ids.ids)],
        }
    
    @api.model
    def process_incoming_mail(self, message):
        """Méthode appelée par le serveur de mail pour traiter les emails entrants"""
        try:
            # Parser l'email
            email_data = self._parse_email_message(message)
            
            # Créer l'enregistrement de traitement
            processing = self.create(email_data)
            
            # Traiter automatiquement si configuré
            if processing.processing_rule_id and processing.processing_rule_id.auto_process:
                processing.action_process()
            
            return processing
            
        except Exception as e:
            # Logger l'erreur
            self.env['ir.logging'].create({
                'name': 'Mail Processing Error',
                'type': 'server',
                'level': 'ERROR',
                'message': f"Erreur traitement email: {str(e)}",
                'func': 'process_incoming_mail',
            })
            
            return False
    
    def _parse_email_message(self, message):
        """Parse un message email et extrait les données"""
        # Logique de parsing des emails
        # À implémenter selon le format des messages reçus
        pass