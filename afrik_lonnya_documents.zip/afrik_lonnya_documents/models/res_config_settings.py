# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import timedelta


class ResConfigSettings(models.TransientModel):
    """Configuration des paramètres pour Afrik Lonnya Documents"""
    _inherit = 'res.config.settings'
    
    # === PARAMÈTRES GÉNÉRAUX ===
    
    # Gestion des documents
    afrik_lonnya_auto_classification = fields.Boolean(
        string='Classification Automatique',
        config_parameter='afrik_lonnya_documents.auto_classification',
        help='Active la classification automatique des documents'
    )
    
    afrik_lonnya_default_classification = fields.Selection([
        ('public', 'Public'),
        ('internal', 'Interne'),
        ('confidential', 'Confidentiel'),
        ('secret', 'Secret')
    ], string='Classification par Défaut',
        config_parameter='afrik_lonnya_documents.default_classification',
        default='internal',
        help='Niveau de classification par défaut pour les nouveaux documents'
    )
    
    afrik_lonnya_auto_archive_days = fields.Integer(
        string='Archivage Automatique (jours)',
        config_parameter='afrik_lonnya_documents.auto_archive_days',
        default=365,
        help='Nombre de jours après lesquels les documents sont automatiquement archivés'
    )
    
    afrik_lonnya_enable_versioning = fields.Boolean(
        string='Activer le Versioning',
        config_parameter='afrik_lonnya_documents.enable_versioning',
        default=True,
        help='Active le système de versioning des documents'
    )
    
    afrik_lonnya_max_versions = fields.Integer(
        string='Nombre Maximum de Versions',
        config_parameter='afrik_lonnya_documents.max_versions',
        default=10,
        help='Nombre maximum de versions à conserver par document'
    )
    
    # === PARAMÈTRES D'APPROBATION ===
    
    afrik_lonnya_enable_approval = fields.Boolean(
        string='Activer les Workflows d\'Approbation',
        config_parameter='afrik_lonnya_documents.enable_approval',
        default=True,
        help='Active le système de workflows d\'approbation'
    )
    
    afrik_lonnya_approval_timeout_days = fields.Integer(
        string='Délai d\'Expiration Approbation (jours)',
        config_parameter='afrik_lonnya_documents.approval_timeout_days',
        default=7,
        help='Délai en jours avant expiration d\'une demande d\'approbation'
    )
    
    afrik_lonnya_approval_reminder_days = fields.Integer(
        string='Rappel Approbation (jours)',
        config_parameter='afrik_lonnya_documents.approval_reminder_days',
        default=3,
        help='Nombre de jours avant expiration pour envoyer un rappel'
    )
    
    afrik_lonnya_auto_approve_same_user = fields.Boolean(
        string='Auto-approbation Même Utilisateur',
        config_parameter='afrik_lonnya_documents.auto_approve_same_user',
        default=False,
        help='Permet l\'auto-approbation si l\'utilisateur est le même que le demandeur'
    )
    
    afrik_lonnya_parallel_approval = fields.Boolean(
        string='Approbation Parallèle',
        config_parameter='afrik_lonnya_documents.parallel_approval',
        default=False,
        help='Permet l\'approbation parallèle (tous les approbateurs en même temps)'
    )
    
    # === PARAMÈTRES EMAIL ===
    
    afrik_lonnya_enable_mail_processing = fields.Boolean(
        string='Activer le Traitement Email',
        config_parameter='afrik_lonnya_documents.enable_mail_processing',
        default=True,
        help='Active le traitement automatique des emails'
    )
    
    afrik_lonnya_mail_auto_process = fields.Boolean(
        string='Traitement Email Automatique',
        config_parameter='afrik_lonnya_documents.mail_auto_process',
        default=True,
        help='Traite automatiquement les emails entrants'
    )
    
    afrik_lonnya_mail_create_documents = fields.Boolean(
        string='Créer Documents depuis Emails',
        config_parameter='afrik_lonnya_documents.mail_create_documents',
        default=True,
        help='Crée automatiquement des documents à partir des pièces jointes email'
    )
    
    afrik_lonnya_mail_default_folder_id = fields.Many2one(
        'documents.folder',
        string='Dossier Email par Défaut',
        config_parameter='afrik_lonnya_documents.mail_default_folder_id',
        help='Dossier par défaut pour les documents créés depuis les emails'
    )
    
    afrik_lonnya_mail_allowed_extensions = fields.Char(
        string='Extensions Autorisées',
        config_parameter='afrik_lonnya_documents.mail_allowed_extensions',
        default='pdf,doc,docx,xls,xlsx,ppt,pptx,txt,jpg,png',
        help='Extensions de fichiers autorisées pour la création de documents (séparées par des virgules)'
    )
    
    afrik_lonnya_mail_max_attachment_size = fields.Float(
        string='Taille Max Pièce Jointe (MB)',
        config_parameter='afrik_lonnya_documents.mail_max_attachment_size',
        default=25.0,
        help='Taille maximale des pièces jointes à traiter (en MB)'
    )
    
    # === PARAMÈTRES DE SÉCURITÉ ===
    
    afrik_lonnya_enable_access_log = fields.Boolean(
        string='Activer les Logs d\'Accès',
        config_parameter='afrik_lonnya_documents.enable_access_log',
        default=True,
        help='Enregistre tous les accès aux documents'
    )
    
    afrik_lonnya_access_log_retention_days = fields.Integer(
        string='Rétention Logs d\'Accès (jours)',
        config_parameter='afrik_lonnya_documents.access_log_retention_days',
        default=90,
        help='Nombre de jours de rétention des logs d\'accès'
    )
    
    afrik_lonnya_require_classification = fields.Boolean(
        string='Classification Obligatoire',
        config_parameter='afrik_lonnya_documents.require_classification',
        default=True,
        help='Rend la classification obligatoire pour tous les documents'
    )
    
    afrik_lonnya_watermark_confidential = fields.Boolean(
        string='Filigrane Documents Confidentiels',
        config_parameter='afrik_lonnya_documents.watermark_confidential',
        default=True,
        help='Ajoute un filigrane aux documents confidentiels'
    )
    
    # === PARAMÈTRES DE NOTIFICATION ===
    
    afrik_lonnya_enable_notifications = fields.Boolean(
        string='Activer les Notifications',
        config_parameter='afrik_lonnya_documents.enable_notifications',
        default=True,
        help='Active le système de notifications'
    )
    
    afrik_lonnya_notification_approval = fields.Boolean(
        string='Notifications d\'Approbation',
        config_parameter='afrik_lonnya_documents.notification_approval',
        default=True,
        help='Envoie des notifications pour les approbations'
    )
    
    afrik_lonnya_notification_expiry = fields.Boolean(
        string='Notifications d\'Expiration',
        config_parameter='afrik_lonnya_documents.notification_expiry',
        default=True,
        help='Envoie des notifications pour les documents qui expirent'
    )
    
    afrik_lonnya_notification_expiry_days = fields.Integer(
        string='Préavis Expiration (jours)',
        config_parameter='afrik_lonnya_documents.notification_expiry_days',
        default=30,
        help='Nombre de jours avant expiration pour envoyer la notification'
    )
    
    # === MÉTHODES DE VALIDATION ===
    
    @api.constrains('afrik_lonnya_auto_archive_days')
    def _check_auto_archive_days(self):
        """Valide le nombre de jours pour l'archivage automatique"""
        for record in self:
            if record.afrik_lonnya_auto_archive_days and record.afrik_lonnya_auto_archive_days < 1:
                raise ValidationError(_("Le nombre de jours pour l'archivage automatique doit être positif."))
    
    @api.constrains('afrik_lonnya_max_versions')
    def _check_max_versions(self):
        """Valide le nombre maximum de versions"""
        for record in self:
            if record.afrik_lonnya_max_versions and record.afrik_lonnya_max_versions < 1:
                raise ValidationError(_("Le nombre maximum de versions doit être positif."))
    
    @api.constrains('afrik_lonnya_approval_timeout_days')
    def _check_approval_timeout_days(self):
        """Valide le délai d'expiration des approbations"""
        for record in self:
            if record.afrik_lonnya_approval_timeout_days and record.afrik_lonnya_approval_timeout_days < 1:
                raise ValidationError(_("Le délai d'expiration des approbations doit être positif."))
    
    @api.constrains('afrik_lonnya_approval_reminder_days')
    def _check_approval_reminder_days(self):
        """Valide le délai de rappel des approbations"""
        for record in self:
            if (record.afrik_lonnya_approval_reminder_days and 
                record.afrik_lonnya_approval_timeout_days and
                record.afrik_lonnya_approval_reminder_days >= record.afrik_lonnya_approval_timeout_days):
                raise ValidationError(_("Le délai de rappel doit être inférieur au délai d'expiration."))
    
    @api.constrains('afrik_lonnya_mail_max_attachment_size')
    def _check_mail_max_attachment_size(self):
        """Valide la taille maximale des pièces jointes"""
        for record in self:
            if record.afrik_lonnya_mail_max_attachment_size and record.afrik_lonnya_mail_max_attachment_size <= 0:
                raise ValidationError(_("La taille maximale des pièces jointes doit être positive."))
    
    @api.constrains('afrik_lonnya_access_log_retention_days')
    def _check_access_log_retention_days(self):
        """Valide la rétention des logs d'accès"""
        for record in self:
            if record.afrik_lonnya_access_log_retention_days and record.afrik_lonnya_access_log_retention_days < 1:
                raise ValidationError(_("La rétention des logs d'accès doit être positive."))
    
    @api.constrains('afrik_lonnya_notification_expiry_days')
    def _check_notification_expiry_days(self):
        """Valide le préavis d'expiration"""
        for record in self:
            if record.afrik_lonnya_notification_expiry_days and record.afrik_lonnya_notification_expiry_days < 1:
                raise ValidationError(_("Le préavis d'expiration doit être positif."))
    
    # === MÉTHODES D'ACTION ===
    
    def action_reset_to_defaults(self):
        """Remet tous les paramètres à leurs valeurs par défaut"""
        default_values = {
            'afrik_lonnya_auto_classification': False,
            'afrik_lonnya_default_classification': 'internal',
            'afrik_lonnya_auto_archive_days': 365,
            'afrik_lonnya_enable_versioning': True,
            'afrik_lonnya_max_versions': 10,
            'afrik_lonnya_enable_approval': True,
            'afrik_lonnya_approval_timeout_days': 7,
            'afrik_lonnya_approval_reminder_days': 3,
            'afrik_lonnya_auto_approve_same_user': False,
            'afrik_lonnya_parallel_approval': False,
            'afrik_lonnya_enable_mail_processing': True,
            'afrik_lonnya_mail_auto_process': True,
            'afrik_lonnya_mail_create_documents': True,
            'afrik_lonnya_mail_allowed_extensions': 'pdf,doc,docx,xls,xlsx,ppt,pptx,txt,jpg,png',
            'afrik_lonnya_mail_max_attachment_size': 25.0,
            'afrik_lonnya_enable_access_log': True,
            'afrik_lonnya_access_log_retention_days': 90,
            'afrik_lonnya_require_classification': True,
            'afrik_lonnya_watermark_confidential': True,
            'afrik_lonnya_enable_notifications': True,
            'afrik_lonnya_notification_approval': True,
            'afrik_lonnya_notification_expiry': True,
            'afrik_lonnya_notification_expiry_days': 30,
        }
        
        self.write(default_values)
        
        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': _('Paramètres Réinitialisés'),
                'message': _('Tous les paramètres ont été remis à leurs valeurs par défaut.'),
                'type': 'success',
            }
        }
    
    def action_cleanup_logs(self):
        """Nettoie les anciens logs"""
        try:
            # Nettoyer les logs d'accès
            if self.afrik_lonnya_access_log_retention_days:
                cutoff_date = fields.Datetime.now() - timedelta(days=self.afrik_lonnya_access_log_retention_days)
                
                # Nettoyer les logs de communication
                comm_logs = self.env['al.communication.log'].search([
                    ('create_date', '<', cutoff_date),
                    ('state', '=', 'active')
                ])
                comm_logs.write({'state': 'archived'})
                
                # Nettoyer les logs de règles email
                rule_logs = self.env['al.mail.rule.log'].search([
                    ('application_date', '<', cutoff_date)
                ])
                rule_logs.unlink()
                
                total_cleaned = len(comm_logs) + len(rule_logs)
                
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Nettoyage Terminé'),
                        'message': _('%d logs ont été nettoyés.') % total_cleaned,
                        'type': 'success',
                    }
                }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Erreur de Nettoyage'),
                    'message': _('Erreur lors du nettoyage: %s') % str(e),
                    'type': 'danger',
                }
            }
    
    def action_create_default_folder(self):
        """Crée le dossier par défaut pour les emails"""
        try:
            folder = self.env['documents.folder'].search([('name', '=', 'Emails')], limit=1)
            
            if not folder:
                folder = self.env['documents.folder'].create({
                    'name': 'Emails',
                    'description': 'Dossier par défaut pour les documents créés depuis les emails',
                })
            
            self.afrik_lonnya_mail_default_folder_id = folder.id
            
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Dossier Créé'),
                    'message': _('Le dossier par défaut pour les emails a été créé.'),
                    'type': 'success',
                }
            }
        except Exception as e:
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Erreur de Création'),
                    'message': _('Erreur lors de la création du dossier: %s') % str(e),
                    'type': 'danger',
                }
            }
    
    @api.model
    def get_values(self):
        """Récupère les valeurs des paramètres"""
        res = super().get_values()
        
        # Récupérer les paramètres spécifiques
        params = self.env['ir.config_parameter'].sudo()
        
        # Ajouter les paramètres Many2one
        mail_folder_id = params.get_param('afrik_lonnya_documents.mail_default_folder_id')
        if mail_folder_id:
            res['afrik_lonnya_mail_default_folder_id'] = int(mail_folder_id)
        
        return res
    
    def set_values(self):
        """Sauvegarde les valeurs des paramètres"""
        super().set_values()
        
        # Sauvegarder les paramètres Many2one
        params = self.env['ir.config_parameter'].sudo()
        
        if self.afrik_lonnya_mail_default_folder_id:
            params.set_param('afrik_lonnya_documents.mail_default_folder_id', self.afrik_lonnya_mail_default_folder_id.id)
        else:
            params.set_param('afrik_lonnya_documents.mail_default_folder_id', False)