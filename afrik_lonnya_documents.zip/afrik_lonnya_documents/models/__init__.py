# -*- coding: utf-8 -*-

from . import document_extension
from . import incoming_mail
from . import outgoing_mail
from . import contract_document
from . import approval_workflow
from . import approval_step
from . import approval_instance
from . import approval_instance_step
from . import document_type
from . import mail_processing
from . import communication_log
from . import res_config_settings
from . import mail_rule