# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import json


class CommunicationLog(models.Model):
    """Modèle pour enregistrer les logs de communication"""
    _name = 'al.communication.log'
    _description = 'Log de Communication'
    _inherit = ['mail.thread']
    _order = 'create_date desc'
    _rec_name = 'display_name'
    
    # Informations de base
    display_name = fields.Char(
        string='Nom d\'Affichage',
        compute='_compute_display_name',
        store=True,
        help='Nom d\'affichage du log'
    )
    
    reference = fields.Char(
        string='Référence',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('Nouveau'),
        help='Référence unique du log'
    )
    
    # Type de communication
    communication_type = fields.Selection([
        ('email', 'Email'),
        ('phone', 'Téléphone'),
        ('meeting', 'Réunion'),
        ('letter', 'Courrier'),
        ('fax', 'Fax'),
        ('sms', 'SMS'),
        ('chat', 'Chat'),
        ('video_call', 'Appel Vidéo'),
        ('other', 'Autre')
    ], string='Type de Communication', required=True, default='email')
    
    # Direction de la communication
    direction = fields.Selection([
        ('in', 'Entrant'),
        ('out', 'Sortant'),
        ('internal', 'Interne')
    ], string='Direction', required=True, default='in')
    
    # Type de log
    log_type = fields.Selection([
        ('info', 'Information'),
        ('warning', 'Avertissement'),
        ('error', 'Erreur'),
        ('success', 'Succès'),
        ('processed', 'Traité'),
        ('failed', 'Échec'),
        ('cancelled', 'Annulé'),
        ('pending', 'En Attente')
    ], string='Type de Log', required=True, default='info')
    
    # Contenu du log
    message = fields.Text(
        string='Message',
        required=True,
        help='Message du log'
    )
    
    details = fields.Text(
        string='Détails',
        help='Détails supplémentaires du log'
    )
    
    # Données techniques
    technical_data = fields.Text(
        string='Données Techniques',
        help='Données techniques en format JSON'
    )
    
    # Relations
    document_id = fields.Many2one(
        'documents.document',
        string='Document',
        help='Document associé au log'
    )
    
    mail_processing_id = fields.Many2one(
        'al.mail.processing',
        string='Traitement Email',
        help='Traitement email associé'
    )
    
    approval_instance_id = fields.Many2one(
        'al.approval.instance',
        string='Instance d\'Approbation',
        help='Instance d\'approbation associée'
    )
    
    # Utilisateur et partenaire
    user_id = fields.Many2one(
        'res.users',
        string='Utilisateur',
        default=lambda self: self.env.user,
        help='Utilisateur qui a généré le log'
    )
    
    partner_id = fields.Many2one(
        'res.partner',
        string='Partenaire',
        help='Partenaire concerné par la communication'
    )
    
    # Informations de contact
    contact_info = fields.Char(
        string='Info Contact',
        help='Informations de contact (email, téléphone, etc.)'
    )
    
    # Priorité
    priority = fields.Selection([
        ('0', 'Normale'),
        ('1', 'Élevée'),
        ('2', 'Urgente')
    ], string='Priorité', default='0')
    
    # État du log
    state = fields.Selection([
        ('active', 'Actif'),
        ('archived', 'Archivé'),
        ('deleted', 'Supprimé')
    ], string='État', default='active', required=True)
    
    # Dates
    communication_date = fields.Datetime(
        string='Date de Communication',
        default=fields.Datetime.now,
        help='Date et heure de la communication'
    )
    
    processed_date = fields.Datetime(
        string='Date de Traitement',
        help='Date et heure du traitement'
    )
    
    # Durée (pour les appels, réunions, etc.)
    duration = fields.Float(
        string='Durée (minutes)',
        help='Durée de la communication en minutes'
    )
    
    # Résultat de la communication
    result = fields.Selection([
        ('success', 'Succès'),
        ('partial', 'Partiel'),
        ('failed', 'Échec'),
        ('pending', 'En Attente')
    ], string='Résultat', default='success')
    
    # Suivi requis
    follow_up_required = fields.Boolean(
        string='Suivi Requis',
        default=False,
        help='Indique si un suivi est requis'
    )
    
    follow_up_date = fields.Datetime(
        string='Date de Suivi',
        help='Date prévue pour le suivi'
    )
    
    follow_up_notes = fields.Text(
        string='Notes de Suivi',
        help='Notes pour le suivi'
    )
    
    # Pièces jointes
    attachment_ids = fields.Many2many(
        'ir.attachment',
        string='Pièces Jointes',
        help='Pièces jointes associées au log'
    )
    
    attachment_count = fields.Integer(
        string='Nombre de Pièces Jointes',
        compute='_compute_attachment_count',
        help='Nombre de pièces jointes'
    )
    
    # Tags
    tag_ids = fields.Many2many(
        'al.communication.tag',
        'comm_log_tag_rel',
        'log_id',
        'tag_id',
        string='Tags',
        help='Tags pour catégoriser le log'
    )
    
    # Statistiques
    view_count = fields.Integer(
        string='Nombre de Vues',
        default=0,
        help='Nombre de fois que le log a été consulté'
    )
    
    last_viewed_date = fields.Datetime(
        string='Dernière Vue',
        help='Date de la dernière consultation'
    )
    
    # Champs calculés
    age_days = fields.Integer(
        string='Âge (jours)',
        compute='_compute_age_days',
        help='Âge du log en jours'
    )
    
    is_recent = fields.Boolean(
        string='Récent',
        compute='_compute_is_recent',
        help='Indique si le log est récent (moins de 24h)'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('reference_unique', 'unique(reference)', 'La référence du log doit être unique.')
    ]
    
    @api.model
    def create(self, vals):
        """Surcharge de create pour générer la référence"""
        if vals.get('reference', _('Nouveau')) == _('Nouveau'):
            vals['reference'] = self.env['ir.sequence'].next_by_code('al.communication.log') or _('Nouveau')
        return super().create(vals)
    
    @api.depends('communication_type', 'direction', 'message', 'communication_date')
    def _compute_display_name(self):
        """Calcule le nom d'affichage"""
        for record in self:
            type_label = dict(record._fields['communication_type'].selection).get(record.communication_type, '')
            direction_label = dict(record._fields['direction'].selection).get(record.direction, '')
            date_str = record.communication_date.strftime('%d/%m/%Y %H:%M') if record.communication_date else ''
            
            record.display_name = f"{type_label} {direction_label} - {date_str}"
    
    @api.depends('attachment_ids')
    def _compute_attachment_count(self):
        """Calcule le nombre de pièces jointes"""
        for record in self:
            record.attachment_count = len(record.attachment_ids)
    
    @api.depends('create_date')
    def _compute_age_days(self):
        """Calcule l'âge en jours"""
        for record in self:
            if record.create_date:
                delta = fields.Datetime.now() - record.create_date
                record.age_days = delta.days
            else:
                record.age_days = 0
    
    @api.depends('create_date')
    def _compute_is_recent(self):
        """Détermine si le log est récent"""
        for record in self:
            if record.create_date:
                delta = fields.Datetime.now() - record.create_date
                record.is_recent = delta.total_seconds() < 86400  # 24 heures
            else:
                record.is_recent = False
    
    def action_mark_as_viewed(self):
        """Marque le log comme consulté"""
        self.write({
            'view_count': self.view_count + 1,
            'last_viewed_date': fields.Datetime.now(),
        })
        return True
    
    def action_archive(self):
        """Archive le log"""
        self.write({'state': 'archived'})
        return True
    
    def action_unarchive(self):
        """Désarchive le log"""
        self.write({'state': 'active'})
        return True
    
    def action_create_follow_up(self):
        """Crée une activité de suivi"""
        if not self.follow_up_required:
            return False
        
        activity_vals = {
            'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
            'summary': f"Suivi: {self.display_name}",
            'note': self.follow_up_notes or self.message,
            'date_deadline': self.follow_up_date.date() if self.follow_up_date else fields.Date.today(),
            'user_id': self.user_id.id,
            'res_model': self._name,
            'res_id': self.id,
        }
        
        activity = self.env['mail.activity'].create(activity_vals)
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Activité de Suivi'),
            'res_model': 'mail.activity',
            'res_id': activity.id,
            'view_mode': 'form',
            'target': 'new',
        }
    
    def set_technical_data(self, data_dict):
        """Définit les données techniques au format JSON"""
        if isinstance(data_dict, dict):
            self.technical_data = json.dumps(data_dict, indent=2, ensure_ascii=False)
        return True
    
    def get_technical_data(self):
        """Récupère les données techniques depuis le JSON"""
        if self.technical_data:
            try:
                return json.loads(self.technical_data)
            except json.JSONDecodeError:
                return {}
        return {}
    
    def action_view_related_document(self):
        """Action pour voir le document associé"""
        if not self.document_id:
            return False
        
        return {
            'type': 'ir.actions.act_window',
            'name': _('Document Associé'),
            'res_model': 'documents.document',
            'res_id': self.document_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
    
    def action_view_attachments(self):
        """Action pour voir les pièces jointes"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Pièces Jointes'),
            'res_model': 'ir.attachment',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', self.attachment_ids.ids)],
        }
    
    @api.model
    def create_log(self, log_type, message, **kwargs):
        """Méthode utilitaire pour créer un log rapidement"""
        vals = {
            'log_type': log_type,
            'message': message,
        }
        vals.update(kwargs)
        
        return self.create(vals)
    
    @api.model
    def create_email_log(self, direction, email_from, email_to, subject, **kwargs):
        """Crée un log spécifique pour les emails"""
        message = f"Email {direction}: {subject}"
        details = f"De: {email_from}\nÀ: {email_to}"
        
        vals = {
            'communication_type': 'email',
            'direction': direction,
            'message': message,
            'details': details,
            'contact_info': email_from if direction == 'in' else email_to,
        }
        vals.update(kwargs)
        
        return self.create(vals)
    
    @api.model
    def cleanup_old_logs(self, days=90):
        """Nettoie les anciens logs (méthode cron)"""
        cutoff_date = fields.Datetime.now() - timedelta(days=days)
        
        old_logs = self.search([
            ('create_date', '<', cutoff_date),
            ('state', '=', 'active'),
            ('follow_up_required', '=', False)
        ])
        
        # Archiver au lieu de supprimer
        old_logs.write({'state': 'archived'})
        
        return len(old_logs)
    
    @api.model
    def get_communication_stats(self, date_from=None, date_to=None):
        """Retourne des statistiques de communication"""
        domain = [('state', '=', 'active')]
        
        if date_from:
            domain.append(('communication_date', '>=', date_from))
        if date_to:
            domain.append(('communication_date', '<=', date_to))
        
        logs = self.search(domain)
        
        stats = {
            'total': len(logs),
            'by_type': {},
            'by_direction': {},
            'by_result': {},
            'recent_count': len(logs.filtered('is_recent')),
        }
        
        # Statistiques par type
        for log in logs:
            # Par type de communication
            if log.communication_type not in stats['by_type']:
                stats['by_type'][log.communication_type] = 0
            stats['by_type'][log.communication_type] += 1
            
            # Par direction
            if log.direction not in stats['by_direction']:
                stats['by_direction'][log.direction] = 0
            stats['by_direction'][log.direction] += 1
            
            # Par résultat
            if log.result not in stats['by_result']:
                stats['by_result'][log.result] = 0
            stats['by_result'][log.result] += 1
        
        return stats


class CommunicationTag(models.Model):
    """Tags pour catégoriser les logs de communication"""
    _name = 'al.communication.tag'
    _description = 'Tag de Communication'
    _order = 'name'
    
    name = fields.Char(
        string='Nom',
        required=True,
        help='Nom du tag'
    )
    
    color = fields.Integer(
        string='Couleur',
        help='Couleur du tag'
    )
    
    description = fields.Text(
        string='Description',
        help='Description du tag'
    )
    
    active = fields.Boolean(
        string='Actif',
        default=True,
        help='Indique si le tag est actif'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('name_unique', 'unique(name)', 'Le nom du tag doit être unique.')
    ]