# -*- coding: utf-8 -*-

from odoo import models, fields, api


class IncomingMail(models.Model):
    """Model for managing incoming mail documents"""
    _name = 'al.incoming.mail'
    _description = 'Incoming Mail Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'reception_date desc'
    
    # Fields will be defined here
    
    # Methods will be implemented here
    pass