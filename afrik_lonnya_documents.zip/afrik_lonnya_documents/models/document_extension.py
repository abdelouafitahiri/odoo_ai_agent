# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta


class DocumentsDocument(models.Model):
    """Extension du modèle documents.document pour les besoins spécifiques d'Afrik Lonnya"""
    _inherit = 'documents.document'
    
    # Champs spécifiques pour la gestion documentaire Afrik Lonnya
    document_type_id = fields.Many2one(
        'afrik.document.type',
        string='Type de Document',
        help='Type spécifique du document pour Afrik Lonnya'
    )
    
    # Champs pour la classification et l'archivage
    reference_number = fields.Char(
        string='Numéro de Référence',
        help='Numéro de référence unique du document'
    )
    
    classification_level = fields.Selection([
        ('public', 'Public'),
        ('internal', 'Interne'),
        ('confidential', 'Confidentiel'),
        ('secret', 'Secret')
    ], string='Niveau de Classification', default='internal')
    
    # Champs pour les dates importantes
    reception_date = fields.Datetime(
        string='Date de Réception',
        help='Date de réception du document'
    )
    
    expiry_date = fields.Date(
        string='Date d\'Expiration',
        help='Date d\'expiration du document'
    )
    
    archival_date = fields.Date(
        string='Date d\'Archivage',
        help='Date prévue pour l\'archivage du document'
    )
    
    # Champs pour le suivi et l'approbation
    approval_status = fields.Selection([
        ('draft', 'Brouillon'),
        ('pending', 'En Attente'),
        ('approved', 'Approuvé'),
        ('rejected', 'Rejeté'),
        ('archived', 'Archivé')
    ], string='Statut d\'Approbation', default='draft', tracking=True)
    
    approved_by = fields.Many2one(
        'res.users',
        string='Approuvé par',
        help='Utilisateur qui a approuvé le document'
    )
    
    approval_date = fields.Datetime(
        string='Date d\'Approbation',
        help='Date d\'approbation du document'
    )
    
    # Champs pour les métadonnées étendues
    keywords = fields.Char(
        string='Mots-clés',
        help='Mots-clés pour la recherche et l\'indexation'
    )
    
    department_id = fields.Many2one(
        'hr.department',
        string='Département',
        help='Département responsable du document'
    )
    
    priority = fields.Selection([
        ('low', 'Faible'),
        ('normal', 'Normal'),
        ('high', 'Élevée'),
        ('urgent', 'Urgent')
    ], string='Priorité', default='normal')
    
    # Champs pour la traçabilité
    version_number = fields.Char(
        string='Numéro de Version',
        default='1.0',
        help='Numéro de version du document'
    )
    
    previous_version_id = fields.Many2one(
        'documents.document',
        string='Version Précédente',
        help='Référence vers la version précédente du document'
    )
    
    is_current_version = fields.Boolean(
        string='Version Actuelle',
        default=True,
        help='Indique si c\'est la version actuelle du document'
    )
    
    # Champs calculés
    days_until_expiry = fields.Integer(
        string='Jours avant Expiration',
        compute='_compute_days_until_expiry',
        help='Nombre de jours avant l\'expiration du document'
    )
    
    is_expired = fields.Boolean(
        string='Expiré',
        compute='_compute_is_expired',
        help='Indique si le document est expiré'
    )
    
    @api.depends('expiry_date')
    def _compute_days_until_expiry(self):
        """Calcule le nombre de jours avant l'expiration"""
        for record in self:
            if record.expiry_date:
                today = fields.Date.today()
                delta = record.expiry_date - today
                record.days_until_expiry = delta.days
            else:
                record.days_until_expiry = 0
    
    @api.depends('expiry_date')
    def _compute_is_expired(self):
        """Détermine si le document est expiré"""
        for record in self:
            if record.expiry_date:
                record.is_expired = record.expiry_date < fields.Date.today()
            else:
                record.is_expired = False
    
    @api.constrains('expiry_date')
    def _check_expiry_date(self):
        """Valide que la date d'expiration est dans le futur"""
        for record in self:
            if record.expiry_date and record.expiry_date < fields.Date.today():
                raise ValidationError(_("La date d'expiration ne peut pas être dans le passé."))
    
    @api.model
    def create(self, vals):
        """Surcharge de la méthode create pour générer automatiquement le numéro de référence"""
        if not vals.get('reference_number'):
            vals['reference_number'] = self._generate_reference_number()
        return super().create(vals)
    
    def _generate_reference_number(self):
        """Génère un numéro de référence unique"""
        sequence = self.env['ir.sequence'].next_by_code('afrik.document.reference') or '/'
        return sequence
    
    def action_approve(self):
        """Action pour approuver le document"""
        self.write({
            'approval_status': 'approved',
            'approved_by': self.env.user.id,
            'approval_date': fields.Datetime.now()
        })
        return True
    
    def action_reject(self):
        """Action pour rejeter le document"""
        self.write({
            'approval_status': 'rejected',
            'approved_by': self.env.user.id,
            'approval_date': fields.Datetime.now()
        })
        return True
    
    def action_archive_document(self):
        """Action pour archiver le document"""
        self.write({
            'approval_status': 'archived',
            'archival_date': fields.Date.today()
        })
        return True
    
    def create_new_version(self):
        """Crée une nouvelle version du document"""
        # Marquer la version actuelle comme non-actuelle
        self.is_current_version = False
        
        # Créer une nouvelle version
        new_version = self.copy({
            'previous_version_id': self.id,
            'is_current_version': True,
            'approval_status': 'draft',
            'approved_by': False,
            'approval_date': False,
        })
        
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'documents.document',
            'res_id': new_version.id,
            'view_mode': 'form',
            'target': 'current',
        }