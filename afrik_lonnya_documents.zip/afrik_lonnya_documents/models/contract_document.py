# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ContractDocument(models.Model):
    """Model for managing contract and agreement documents"""
    _name = 'al.contract.document'
    _description = 'Contract Document Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'contract_date desc'
    
    # Fields will be defined here
    
    # Methods will be implemented here
    pass