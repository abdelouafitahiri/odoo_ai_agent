# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
import re


class MailRule(models.Model):
    """Modèle pour définir les règles de traitement automatique des emails"""
    _name = 'al.mail.rule'
    _description = 'Règle de Traitement Email'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'sequence, name'
    
    name = fields.Char(
        string='Nom de la Règle',
        required=True,
        help='Nom descriptif de la règle'
    )
    
    code = fields.Char(
        string='Code',
        required=True,
        help='Code unique de la règle'
    )
    
    description = fields.Text(
        string='Description',
        help='Description détaillée de la règle'
    )
    
    # Configuration de base
    active = fields.Boolean(
        string='Actif',
        default=True,
        help='Indique si la règle est active'
    )
    
    sequence = fields.Integer(
        string='Séquence',
        default=10,
        help='Ordre d\'application des règles (plus petit = priorité plus élevée)'
    )
    
    # Type de traitement
    processing_type = fields.Selection([
        ('incoming', 'Email Entrant'),
        ('outgoing', 'Email Sortant'),
        ('internal', 'Email Interne'),
        ('all', 'Tous Types')
    ], string='Type de Traitement', required=True, default='incoming')
    
    # Conditions de correspondance
    match_type = fields.Selection([
        ('all', 'Toutes les Conditions'),
        ('any', 'Au Moins une Condition')
    ], string='Type de Correspondance', default='all', required=True)
    
    # Conditions sur l'expéditeur
    sender_condition = fields.Selection([
        ('none', 'Aucune'),
        ('contains', 'Contient'),
        ('equals', 'Égal à'),
        ('starts_with', 'Commence par'),
        ('ends_with', 'Finit par'),
        ('regex', 'Expression Régulière'),
        ('domain', 'Domaine')
    ], string='Condition Expéditeur', default='none')
    
    sender_value = fields.Char(
        string='Valeur Expéditeur',
        help='Valeur pour la condition expéditeur'
    )
    
    # Conditions sur le destinataire
    recipient_condition = fields.Selection([
        ('none', 'Aucune'),
        ('contains', 'Contient'),
        ('equals', 'Égal à'),
        ('starts_with', 'Commence par'),
        ('ends_with', 'Finit par'),
        ('regex', 'Expression Régulière'),
        ('domain', 'Domaine')
    ], string='Condition Destinataire', default='none')
    
    recipient_value = fields.Char(
        string='Valeur Destinataire',
        help='Valeur pour la condition destinataire'
    )
    
    # Conditions sur le sujet
    subject_condition = fields.Selection([
        ('none', 'Aucune'),
        ('contains', 'Contient'),
        ('equals', 'Égal à'),
        ('starts_with', 'Commence par'),
        ('ends_with', 'Finit par'),
        ('regex', 'Expression Régulière')
    ], string='Condition Sujet', default='none')
    
    subject_value = fields.Char(
        string='Valeur Sujet',
        help='Valeur pour la condition sujet'
    )
    
    # Conditions sur le corps
    body_condition = fields.Selection([
        ('none', 'Aucune'),
        ('contains', 'Contient'),
        ('regex', 'Expression Régulière')
    ], string='Condition Corps', default='none')
    
    body_value = fields.Text(
        string='Valeur Corps',
        help='Valeur pour la condition corps'
    )
    
    # Conditions sur les pièces jointes
    attachment_condition = fields.Selection([
        ('none', 'Aucune'),
        ('has_attachments', 'A des Pièces Jointes'),
        ('no_attachments', 'Aucune Pièce Jointe'),
        ('extension', 'Extension Spécifique'),
        ('filename', 'Nom de Fichier'),
        ('size_min', 'Taille Minimale'),
        ('size_max', 'Taille Maximale')
    ], string='Condition Pièces Jointes', default='none')
    
    attachment_value = fields.Char(
        string='Valeur Pièces Jointes',
        help='Valeur pour la condition pièces jointes'
    )
    
    # Conditions temporelles
    time_condition = fields.Selection([
        ('none', 'Aucune'),
        ('business_hours', 'Heures Ouvrables'),
        ('after_hours', 'Hors Heures Ouvrables'),
        ('weekend', 'Week-end'),
        ('holiday', 'Jour Férié')
    ], string='Condition Temporelle', default='none')
    
    # Actions à effectuer
    auto_process = fields.Boolean(
        string='Traitement Automatique',
        default=True,
        help='Traite automatiquement les emails correspondants'
    )
    
    create_email_document = fields.Boolean(
        string='Créer Document Email',
        default=False,
        help='Crée un document pour l\'email lui-même'
    )
    
    create_attachment_documents = fields.Boolean(
        string='Créer Documents Pièces Jointes',
        default=True,
        help='Crée des documents pour les pièces jointes'
    )
    
    # Classification automatique
    auto_classification = fields.Selection([
        ('public', 'Public'),
        ('internal', 'Interne'),
        ('confidential', 'Confidentiel'),
        ('secret', 'Secret')
    ], string='Classification Automatique')
    
    # Dossier de destination
    target_folder_id = fields.Many2one(
        'documents.folder',
        string='Dossier de Destination',
        help='Dossier où placer les documents créés'
    )
    
    # Type de document par défaut
    default_document_type_id = fields.Many2one(
        'al.document.type',
        string='Type de Document par Défaut',
        help='Type de document à assigner par défaut'
    )
    
    # Tags à appliquer
    tag_ids = fields.Many2many(
        'documents.tag',
        string='Tags à Appliquer',
        help='Tags à appliquer aux documents créés'
    )
    
    # Workflow d'approbation
    approval_workflow_id = fields.Many2one(
        'al.approval.workflow',
        string='Workflow d\'Approbation',
        help='Workflow d\'approbation à déclencher'
    )
    
    # Notifications
    send_notification = fields.Boolean(
        string='Envoyer Notification',
        default=False,
        help='Envoie une notification lors du traitement'
    )
    
    notification_user_ids = fields.Many2many(
        'res.users',
        string='Utilisateurs à Notifier',
        help='Utilisateurs à notifier lors du traitement'
    )
    
    notification_template_id = fields.Many2one(
        'mail.template',
        string='Modèle de Notification',
        help='Modèle d\'email pour les notifications'
    )
    
    # Actions personnalisées
    custom_action = fields.Selection([
        ('none', 'Aucune'),
        ('forward', 'Transférer'),
        ('reply', 'Répondre Automatiquement'),
        ('archive', 'Archiver'),
        ('delete', 'Supprimer')
    ], string='Action Personnalisée', default='none')
    
    forward_to = fields.Char(
        string='Transférer À',
        help='Adresse email pour le transfert'
    )
    
    auto_reply_template_id = fields.Many2one(
        'mail.template',
        string='Modèle de Réponse Auto',
        help='Modèle pour la réponse automatique'
    )
    
    # Statistiques
    usage_count = fields.Integer(
        string='Nombre d\'Utilisations',
        default=0,
        readonly=True,
        help='Nombre de fois que la règle a été appliquée'
    )
    
    last_used_date = fields.Datetime(
        string='Dernière Utilisation',
        readonly=True,
        help='Date de la dernière utilisation'
    )
    
    success_rate = fields.Float(
        string='Taux de Succès (%)',
        compute='_compute_success_rate',
        help='Taux de succès de la règle'
    )
    
    # Logs d'application
    log_ids = fields.One2many(
        'al.mail.rule.log',
        'rule_id',
        string='Logs d\'Application',
        help='Historique d\'application de la règle'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('code_unique', 'unique(code)', 'Le code de la règle doit être unique.')
    ]
    
    @api.constrains('sender_value', 'sender_condition')
    def _check_sender_regex(self):
        """Valide l'expression régulière de l'expéditeur"""
        for record in self:
            if record.sender_condition == 'regex' and record.sender_value:
                try:
                    re.compile(record.sender_value)
                except re.error as e:
                    raise ValidationError(_("Expression régulière invalide pour l'expéditeur: %s") % str(e))
    
    @api.constrains('subject_value', 'subject_condition')
    def _check_subject_regex(self):
        """Valide l'expression régulière du sujet"""
        for record in self:
            if record.subject_condition == 'regex' and record.subject_value:
                try:
                    re.compile(record.subject_value)
                except re.error as e:
                    raise ValidationError(_("Expression régulière invalide pour le sujet: %s") % str(e))
    
    @api.constrains('body_value', 'body_condition')
    def _check_body_regex(self):
        """Valide l'expression régulière du corps"""
        for record in self:
            if record.body_condition == 'regex' and record.body_value:
                try:
                    re.compile(record.body_value)
                except re.error as e:
                    raise ValidationError(_("Expression régulière invalide pour le corps: %s") % str(e))
    
    @api.depends('log_ids.success')
    def _compute_success_rate(self):
        """Calcule le taux de succès"""
        for record in self:
            if record.log_ids:
                success_count = len(record.log_ids.filtered('success'))
                total_count = len(record.log_ids)
                record.success_rate = (success_count / total_count) * 100 if total_count > 0 else 0
            else:
                record.success_rate = 0
    
    def matches_email(self, email_processing):
        """Vérifie si un email correspond à cette règle"""
        conditions_met = []
        
        # Vérifier le type de traitement
        if self.processing_type != 'all' and self.processing_type != email_processing.processing_type:
            return False
        
        # Condition expéditeur
        if self.sender_condition != 'none':
            sender_match = self._check_condition(
                email_processing.email_from or '',
                self.sender_condition,
                self.sender_value or ''
            )
            conditions_met.append(sender_match)
        
        # Condition destinataire
        if self.recipient_condition != 'none':
            recipient_match = self._check_condition(
                email_processing.email_to or '',
                self.recipient_condition,
                self.recipient_value or ''
            )
            conditions_met.append(recipient_match)
        
        # Condition sujet
        if self.subject_condition != 'none':
            subject_match = self._check_condition(
                email_processing.subject or '',
                self.subject_condition,
                self.subject_value or ''
            )
            conditions_met.append(subject_match)
        
        # Condition corps
        if self.body_condition != 'none':
            body_text = email_processing.body_text or email_processing.body_html or ''
            body_match = self._check_condition(
                body_text,
                self.body_condition,
                self.body_value or ''
            )
            conditions_met.append(body_match)
        
        # Condition pièces jointes
        if self.attachment_condition != 'none':
            attachment_match = self._check_attachment_condition(email_processing)
            conditions_met.append(attachment_match)
        
        # Condition temporelle
        if self.time_condition != 'none':
            time_match = self._check_time_condition(email_processing)
            conditions_met.append(time_match)
        
        # Évaluer selon le type de correspondance
        if not conditions_met:
            return True  # Aucune condition = correspond toujours
        
        if self.match_type == 'all':
            return all(conditions_met)
        else:  # any
            return any(conditions_met)
    
    def _check_condition(self, value, condition, pattern):
        """Vérifie une condition sur une valeur"""
        if not value:
            value = ''
        
        value = value.lower()
        pattern = pattern.lower()
        
        if condition == 'contains':
            return pattern in value
        elif condition == 'equals':
            return value == pattern
        elif condition == 'starts_with':
            return value.startswith(pattern)
        elif condition == 'ends_with':
            return value.endswith(pattern)
        elif condition == 'regex':
            try:
                return bool(re.search(pattern, value, re.IGNORECASE))
            except re.error:
                return False
        elif condition == 'domain':
            # Extraire le domaine de l'email
            if '@' in value:
                domain = value.split('@')[-1]
                return domain == pattern
            return False
        
        return False
    
    def _check_attachment_condition(self, email_processing):
        """Vérifie les conditions sur les pièces jointes"""
        attachments = email_processing.attachment_ids
        
        if self.attachment_condition == 'has_attachments':
            return len(attachments) > 0
        elif self.attachment_condition == 'no_attachments':
            return len(attachments) == 0
        elif self.attachment_condition == 'extension':
            if not self.attachment_value:
                return False
            ext = self.attachment_value.lower()
            if not ext.startswith('.'):
                ext = '.' + ext
            return any(att.name and att.name.lower().endswith(ext) for att in attachments)
        elif self.attachment_condition == 'filename':
            if not self.attachment_value:
                return False
            pattern = self.attachment_value.lower()
            return any(att.name and pattern in att.name.lower() for att in attachments)
        elif self.attachment_condition == 'size_min':
            try:
                min_size = float(self.attachment_value or 0)
                return any(att.file_size >= min_size for att in attachments)
            except ValueError:
                return False
        elif self.attachment_condition == 'size_max':
            try:
                max_size = float(self.attachment_value or 0)
                return any(att.file_size <= max_size for att in attachments)
            except ValueError:
                return False
        
        return False
    
    def _check_time_condition(self, email_processing):
        """Vérifie les conditions temporelles"""
        email_date = email_processing.email_date or fields.Datetime.now()
        
        if self.time_condition == 'business_hours':
            # Heures ouvrables : 8h-18h, lundi-vendredi
            weekday = email_date.weekday()  # 0=lundi, 6=dimanche
            hour = email_date.hour
            return weekday < 5 and 8 <= hour < 18
        elif self.time_condition == 'after_hours':
            weekday = email_date.weekday()
            hour = email_date.hour
            return weekday >= 5 or hour < 8 or hour >= 18
        elif self.time_condition == 'weekend':
            weekday = email_date.weekday()
            return weekday >= 5  # Samedi ou dimanche
        elif self.time_condition == 'holiday':
            # TODO: Implémenter la vérification des jours fériés
            return False
        
        return False
    
    def apply_to_email(self, email_processing):
        """Applique la règle à un email"""
        success = True
        error_message = ''
        
        try:
            # Incrémenter le compteur d'utilisation
            self.write({
                'usage_count': self.usage_count + 1,
                'last_used_date': fields.Datetime.now(),
            })
            
            # Appliquer la classification
            if self.auto_classification:
                email_processing.classification = self.auto_classification
            
            # Définir le dossier de destination
            if self.target_folder_id:
                # Cette information sera utilisée lors de la création des documents
                pass
            
            # Appliquer les tags
            if self.tag_ids:
                # Les tags seront appliqués lors de la création des documents
                pass
            
            # Déclencher le workflow d'approbation
            if self.approval_workflow_id:
                # Le workflow sera déclenché après la création des documents
                pass
            
            # Envoyer des notifications
            if self.send_notification and self.notification_user_ids:
                self._send_notification(email_processing)
            
            # Actions personnalisées
            if self.custom_action != 'none':
                self._execute_custom_action(email_processing)
            
        except Exception as e:
            success = False
            error_message = str(e)
        
        # Créer un log d'application
        self._create_application_log(email_processing, success, error_message)
        
        return success
    
    def _send_notification(self, email_processing):
        """Envoie une notification"""
        if self.notification_template_id:
            # Utiliser le modèle d'email
            for user in self.notification_user_ids:
                self.notification_template_id.with_context(
                    email_processing=email_processing,
                    rule=self
                ).send_mail(email_processing.id, force_send=True)
        else:
            # Notification simple
            subject = _("Règle de traitement email appliquée: %s") % self.name
            body = _("La règle '%s' a été appliquée à l'email: %s") % (self.name, email_processing.subject or 'Sans sujet')
            
            for user in self.notification_user_ids:
                self.env['mail.mail'].create({
                    'subject': subject,
                    'body_html': f"<p>{body}</p>",
                    'email_to': user.email,
                    'auto_delete': True,
                })
    
    def _execute_custom_action(self, email_processing):
        """Exécute une action personnalisée"""
        if self.custom_action == 'forward' and self.forward_to:
            # Logique de transfert
            pass
        elif self.custom_action == 'reply' and self.auto_reply_template_id:
            # Logique de réponse automatique
            pass
        elif self.custom_action == 'archive':
            # Archiver l'email
            email_processing.write({'state': 'processed'})
        elif self.custom_action == 'delete':
            # Marquer pour suppression
            email_processing.write({'state': 'cancelled'})
    
    def _create_application_log(self, email_processing, success, error_message=''):
        """Crée un log d'application de la règle"""
        log_vals = {
            'rule_id': self.id,
            'mail_processing_id': email_processing.id,
            'success': success,
            'error_message': error_message,
            'application_date': fields.Datetime.now(),
        }
        
        return self.env['al.mail.rule.log'].create(log_vals)
    
    def action_test_rule(self):
        """Action pour tester la règle"""
        # Ouvrir un assistant de test
        return {
            'type': 'ir.actions.act_window',
            'name': _('Tester la Règle'),
            'res_model': 'al.mail.rule.test.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_rule_id': self.id},
        }
    
    def action_view_logs(self):
        """Action pour voir les logs d'application"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Logs d\'Application'),
            'res_model': 'al.mail.rule.log',
            'view_mode': 'tree,form',
            'domain': [('rule_id', '=', self.id)],
        }
    
    @api.model
    def find_matching_rules(self, email_processing):
        """Trouve toutes les règles correspondant à un email"""
        rules = self.search([
            ('active', '=', True),
            '|',
            ('processing_type', '=', email_processing.processing_type),
            ('processing_type', '=', 'all')
        ], order='sequence')
        
        matching_rules = []
        for rule in rules:
            if rule.matches_email(email_processing):
                matching_rules.append(rule)
        
        return matching_rules


class MailRuleLog(models.Model):
    """Log d'application des règles de traitement email"""
    _name = 'al.mail.rule.log'
    _description = 'Log d\'Application de Règle Email'
    _order = 'application_date desc'
    
    rule_id = fields.Many2one(
        'al.mail.rule',
        string='Règle',
        required=True,
        ondelete='cascade',
        help='Règle appliquée'
    )
    
    mail_processing_id = fields.Many2one(
        'al.mail.processing',
        string='Traitement Email',
        required=True,
        ondelete='cascade',
        help='Email traité'
    )
    
    success = fields.Boolean(
        string='Succès',
        default=True,
        help='Indique si l\'application a réussi'
    )
    
    error_message = fields.Text(
        string='Message d\'Erreur',
        help='Message d\'erreur en cas d\'échec'
    )
    
    application_date = fields.Datetime(
        string='Date d\'Application',
        default=fields.Datetime.now,
        help='Date et heure d\'application'
    )
    
    processing_time = fields.Float(
        string='Temps de Traitement (ms)',
        help='Temps de traitement en millisecondes'
    )
    
    details = fields.Text(
        string='Détails',
        help='Détails supplémentaires sur l\'application'
    )