# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta


class ApprovalInstance(models.Model):
    """Modèle d'instance d'approbation pour suivre les processus d'approbation en cours"""
    _name = 'al.approval.instance'
    _description = 'Instance d\'Approbation'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'create_date desc'
    
    name = fields.Char(
        string='Référence',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('Nouveau'),
        help='Référence unique de l\'instance d\'approbation'
    )
    
    # Relations principales
    workflow_id = fields.Many2one(
        'al.approval.workflow',
        string='Workflow',
        required=True,
        readonly=True,
        help='Workflow d\'approbation utilisé'
    )
    
    document_id = fields.Many2one(
        'documents.document',
        string='Document',
        required=True,
        readonly=True,
        help='Document en cours d\'approbation'
    )
    
    # État et progression
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('in_progress', 'En Cours'),
        ('approved', 'Approuvé'),
        ('rejected', 'Rejeté'),
        ('cancelled', 'Annulé'),
        ('expired', 'Expiré')
    ], string='État', default='draft', tracking=True, required=True)
    
    current_step_id = fields.Many2one(
        'al.approval.step',
        string='Étape Actuelle',
        readonly=True,
        help='Étape actuellement en cours'
    )
    
    progress_percentage = fields.Float(
        string='Progression (%)',
        compute='_compute_progress_percentage',
        help='Pourcentage de progression du workflow'
    )
    
    # Dates importantes
    start_date = fields.Datetime(
        string='Date de Début',
        readonly=True,
        help='Date de démarrage du workflow'
    )
    
    completion_date = fields.Datetime(
        string='Date de Finalisation',
        readonly=True,
        help='Date de finalisation du workflow'
    )
    
    deadline_date = fields.Datetime(
        string='Date Limite',
        help='Date limite pour finaliser le workflow'
    )
    
    # Informations sur le demandeur
    requester_id = fields.Many2one(
        'res.users',
        string='Demandeur',
        required=True,
        readonly=True,
        default=lambda self: self.env.user,
        help='Utilisateur ayant initié la demande d\'approbation'
    )
    
    requester_comment = fields.Text(
        string='Commentaire du Demandeur',
        help='Commentaire initial du demandeur'
    )
    
    # Informations sur l'approbation finale
    final_approver_id = fields.Many2one(
        'res.users',
        string='Approbateur Final',
        readonly=True,
        help='Utilisateur ayant donné l\'approbation finale'
    )
    
    final_comment = fields.Text(
        string='Commentaire Final',
        readonly=True,
        help='Commentaire de l\'approbation ou du rejet final'
    )
    
    # Configuration et métadonnées
    priority = fields.Selection([
        ('0', 'Normale'),
        ('1', 'Élevée'),
        ('2', 'Urgente')
    ], string='Priorité', default='0')
    
    auto_started = fields.Boolean(
        string='Démarrage Automatique',
        readonly=True,
        help='Indique si le workflow a été démarré automatiquement'
    )
    
    can_be_cancelled = fields.Boolean(
        string='Peut être Annulé',
        compute='_compute_can_be_cancelled',
        help='Indique si l\'instance peut être annulée'
    )
    
    # Statistiques et métriques
    total_steps = fields.Integer(
        string='Nombre Total d\'Étapes',
        compute='_compute_total_steps',
        help='Nombre total d\'étapes dans ce workflow'
    )
    
    completed_steps = fields.Integer(
        string='Étapes Complétées',
        compute='_compute_completed_steps',
        help='Nombre d\'étapes complétées'
    )
    
    processing_time = fields.Float(
        string='Temps de Traitement (heures)',
        compute='_compute_processing_time',
        help='Temps total de traitement en heures'
    )
    
    # Relations
    step_instance_ids = fields.One2many(
        'al.approval.instance.step',
        'instance_id',
        string='Étapes d\'Instance',
        help='Étapes de cette instance d\'approbation'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('name_unique', 'unique(name)', 'La référence de l\'instance doit être unique.')
    ]
    
    @api.model
    def create(self, vals):
        """Surcharge de create pour générer la référence"""
        if vals.get('name', _('Nouveau')) == _('Nouveau'):
            vals['name'] = self.env['ir.sequence'].next_by_code('al.approval.instance') or _('Nouveau')
        return super().create(vals)
    
    @api.depends('step_instance_ids')
    def _compute_total_steps(self):
        """Calcule le nombre total d'étapes"""
        for record in self:
            record.total_steps = len(record.step_instance_ids)
    
    @api.depends('step_instance_ids')
    def _compute_completed_steps(self):
        """Calcule le nombre d'étapes complétées"""
        for record in self:
            record.completed_steps = len(record.step_instance_ids.filtered(
                lambda x: x.state in ['approved', 'rejected']
            ))
    
    @api.depends('completed_steps', 'total_steps')
    def _compute_progress_percentage(self):
        """Calcule le pourcentage de progression"""
        for record in self:
            if record.total_steps > 0:
                record.progress_percentage = (record.completed_steps / record.total_steps) * 100
            else:
                record.progress_percentage = 0.0
    
    @api.depends('start_date', 'completion_date')
    def _compute_processing_time(self):
        """Calcule le temps de traitement"""
        for record in self:
            if record.start_date:
                end_date = record.completion_date or fields.Datetime.now()
                delta = end_date - record.start_date
                record.processing_time = delta.total_seconds() / 3600
            else:
                record.processing_time = 0.0
    
    @api.depends('state', 'requester_id')
    def _compute_can_be_cancelled(self):
        """Détermine si l'instance peut être annulée"""
        for record in self:
            record.can_be_cancelled = (
                record.state in ['draft', 'in_progress'] and
                (record.requester_id == self.env.user or 
                 self.env.user.has_group('afrik_lonnya_documents.group_document_manager'))
            )
    
    def action_start(self):
        """Démarre le processus d'approbation"""
        if self.state != 'draft':
            raise UserError(_("Seules les instances en brouillon peuvent être démarrées."))
        
        if not self.step_instance_ids:
            raise UserError(_("Aucune étape définie pour cette instance."))
        
        # Marquer comme démarré
        self.write({
            'state': 'in_progress',
            'start_date': fields.Datetime.now(),
        })
        
        # Activer la première étape selon le type de workflow
        if self.workflow_id.workflow_type == 'sequential':
            first_step = self.step_instance_ids.sorted('step_id.sequence')[0]
            first_step.action_activate()
        elif self.workflow_id.workflow_type == 'parallel':
            # Activer toutes les étapes en parallèle
            for step in self.step_instance_ids:
                step.action_activate()
        
        # Envoyer les notifications si configuré
        if self.workflow_id.notify_on_start:
            self._send_notification('start')
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("Le processus d'approbation a été démarré."),
            message_type='notification'
        )
        
        return True
    
    def action_approve(self, comment=None):
        """Approuve l'instance (approbation finale)"""
        if self.state != 'in_progress':
            raise UserError(_("Seules les instances en cours peuvent être approuvées."))
        
        # Vérifier que toutes les étapes requises sont approuvées
        pending_steps = self.step_instance_ids.filtered(
            lambda x: x.state in ['pending', 'waiting']
        )
        
        if pending_steps:
            raise UserError(_("Toutes les étapes doivent être approuvées avant l'approbation finale."))
        
        # Marquer comme approuvé
        self.write({
            'state': 'approved',
            'completion_date': fields.Datetime.now(),
            'final_approver_id': self.env.user.id,
            'final_comment': comment or '',
        })
        
        # Mettre à jour le document
        if hasattr(self.document_id, 'approval_state'):
            self.document_id.approval_state = 'approved'
        
        # Envoyer les notifications
        if self.workflow_id.notify_on_completion:
            self._send_notification('approved')
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("Le document a été approuvé. %s") % (comment or ''),
            message_type='notification'
        )
        
        return True
    
    def action_reject(self, comment=None):
        """Rejette l'instance"""
        if self.state not in ['draft', 'in_progress']:
            raise UserError(_("Seules les instances en brouillon ou en cours peuvent être rejetées."))
        
        # Marquer comme rejeté
        self.write({
            'state': 'rejected',
            'completion_date': fields.Datetime.now(),
            'final_approver_id': self.env.user.id,
            'final_comment': comment or '',
        })
        
        # Annuler toutes les étapes en attente
        pending_steps = self.step_instance_ids.filtered(
            lambda x: x.state in ['pending', 'waiting']
        )
        pending_steps.write({'state': 'cancelled'})
        
        # Mettre à jour le document
        if hasattr(self.document_id, 'approval_state'):
            self.document_id.approval_state = 'rejected'
        
        # Envoyer les notifications
        if self.workflow_id.notify_on_rejection:
            self._send_notification('rejected')
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("Le document a été rejeté. %s") % (comment or ''),
            message_type='notification'
        )
        
        return True
    
    def action_cancel(self):
        """Annule l'instance"""
        if not self.can_be_cancelled:
            raise UserError(_("Cette instance ne peut pas être annulée."))
        
        # Marquer comme annulé
        self.write({
            'state': 'cancelled',
            'completion_date': fields.Datetime.now(),
        })
        
        # Annuler toutes les étapes
        self.step_instance_ids.write({'state': 'cancelled'})
        
        # Mettre à jour le document
        if hasattr(self.document_id, 'approval_state'):
            self.document_id.approval_state = 'draft'
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("Le processus d'approbation a été annulé."),
            message_type='notification'
        )
        
        return True
    
    def action_reset_to_draft(self):
        """Remet l'instance en brouillon"""
        if self.state not in ['cancelled', 'rejected']:
            raise UserError(_("Seules les instances annulées ou rejetées peuvent être remises en brouillon."))
        
        # Vérifier les permissions
        if not self.env.user.has_group('afrik_lonnya_documents.group_document_manager'):
            raise UserError(_("Seuls les gestionnaires de documents peuvent remettre en brouillon."))
        
        # Remettre en brouillon
        self.write({
            'state': 'draft',
            'start_date': False,
            'completion_date': False,
            'final_approver_id': False,
            'final_comment': False,
        })
        
        # Remettre les étapes en attente
        self.step_instance_ids.write({'state': 'waiting'})
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'instance a été remise en brouillon."),
            message_type='notification'
        )
        
        return True
    
    def check_expiration(self):
        """Vérifie et traite les instances expirées"""
        expired_instances = self.search([
            ('state', '=', 'in_progress'),
            ('deadline_date', '!=', False),
            ('deadline_date', '<', fields.Datetime.now())
        ])
        
        for instance in expired_instances:
            instance.write({
                'state': 'expired',
                'completion_date': fields.Datetime.now(),
            })
            
            # Mettre à jour le document
            if hasattr(instance.document_id, 'approval_state'):
                instance.document_id.approval_state = 'expired'
            
            # Enregistrer dans le chatter
            instance.message_post(
                body=_("Le processus d'approbation a expiré."),
                message_type='notification'
            )
        
        return len(expired_instances)
    
    def _send_notification(self, notification_type):
        """Envoie une notification selon le type"""
        # Logique de notification à implémenter selon les besoins
        # Peut utiliser mail.template ou envoyer des emails directs
        pass
    
    def get_next_approvers(self):
        """Retourne les prochains approbateurs"""
        if self.current_step_id:
            return self.current_step_id.get_approvers(self.document_id)
        return self.env['res.users']
    
    def action_view_document(self):
        """Action pour voir le document associé"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Document'),
            'res_model': 'documents.document',
            'res_id': self.document_id.id,
            'view_mode': 'form',
            'target': 'current',
        }
    
    @api.model
    def cron_check_expiration(self):
        """Tâche cron pour vérifier les expirations"""
        return self.check_expiration()
    
    @api.model
    def cron_send_reminders(self):
        """Tâche cron pour envoyer les rappels"""
        # Logique pour envoyer des rappels aux approbateurs
        # selon la configuration des étapes
        pass