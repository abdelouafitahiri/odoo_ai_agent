# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class ApprovalWorkflow(models.Model):
    """Modèle de workflow d'approbation pour les processus d'approbation de documents"""
    _name = 'al.approval.workflow'
    _description = 'Document Approval Workflow'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'sequence, name'
    
    name = fields.Char(
        string='Nom',
        required=True,
        translate=True,
        help='Nom du workflow d\'approbation'
    )
    
    code = fields.Char(
        string='Code',
        required=True,
        help='Code unique pour identifier le workflow'
    )
    
    description = fields.Text(
        string='Description',
        translate=True,
        help='Description détaillée du workflow d\'approbation'
    )
    
    sequence = fields.Integer(
        string='Séquence',
        default=10,
        help='Ordre d\'affichage du workflow'
    )
    
    active = fields.Boolean(
        string='Actif',
        default=True,
        help='Indique si le workflow est actif'
    )
    
    # Configuration du workflow
    workflow_type = fields.Selection([
        ('sequential', 'Séquentiel'),
        ('parallel', 'Parallèle'),
        ('conditional', 'Conditionnel')
    ], string='Type de Workflow', required=True, default='sequential')
    
    auto_start = fields.Boolean(
        string='Démarrage Automatique',
        default=True,
        help='Démarre automatiquement le workflow lors de la création du document'
    )
    
    # Étapes du workflow
    step_ids = fields.One2many(
        'al.approval.step',
        'workflow_id',
        string='Étapes',
        help='Étapes du workflow d\'approbation'
    )
    
    # Configuration des notifications
    notify_on_start = fields.Boolean(
        string='Notifier au Démarrage',
        default=True,
        help='Envoie une notification au démarrage du workflow'
    )
    
    notify_on_approval = fields.Boolean(
        string='Notifier à l\'Approbation',
        default=True,
        help='Envoie une notification à chaque approbation'
    )
    
    notify_on_rejection = fields.Boolean(
        string='Notifier au Rejet',
        default=True,
        help='Envoie une notification en cas de rejet'
    )
    
    notify_on_completion = fields.Boolean(
        string='Notifier à la Finalisation',
        default=True,
        help='Envoie une notification à la fin du workflow'
    )
    
    # Configuration des délais
    default_timeout_days = fields.Integer(
        string='Délai par Défaut (jours)',
        default=7,
        help='Délai par défaut pour chaque étape en jours'
    )
    
    escalation_enabled = fields.Boolean(
        string='Escalade Activée',
        default=False,
        help='Active l\'escalade automatique en cas de dépassement de délai'
    )
    
    escalation_days = fields.Integer(
        string='Délai d\'Escalade (jours)',
        default=3,
        help='Nombre de jours après le délai pour déclencher l\'escalade'
    )
    
    # Statistiques
    document_count = fields.Integer(
        string='Nombre de Documents',
        compute='_compute_document_count',
        help='Nombre de documents utilisant ce workflow'
    )
    
    avg_completion_time = fields.Float(
        string='Temps Moyen de Finalisation (jours)',
        compute='_compute_avg_completion_time',
        help='Temps moyen de finalisation du workflow en jours'
    )
    
    success_rate = fields.Float(
        string='Taux de Réussite (%)',
        compute='_compute_success_rate',
        help='Pourcentage de workflows finalisés avec succès'
    )
    
    # Relations
    document_type_ids = fields.One2many(
        'al.document.type',
        'approval_workflow_id',
        string='Types de Documents',
        help='Types de documents utilisant ce workflow'
    )
    
    approval_instance_ids = fields.One2many(
        'al.approval.instance',
        'workflow_id',
        string='Instances d\'Approbation',
        help='Instances d\'approbation de ce workflow'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('code_unique', 'unique(code)', 'Le code du workflow doit être unique.'),
        ('name_unique', 'unique(name)', 'Le nom du workflow doit être unique.'),
        ('timeout_positive', 'check(default_timeout_days > 0)', 
         'Le délai par défaut doit être positif.'),
        ('escalation_positive', 'check(escalation_days > 0)', 
         'Le délai d\'escalade doit être positif.')
    ]
    
    @api.depends('document_type_ids')
    def _compute_document_count(self):
        """Calcule le nombre de documents utilisant ce workflow"""
        for record in self:
            count = 0
            for doc_type in record.document_type_ids:
                count += doc_type.document_count
            record.document_count = count
    
    @api.depends('approval_instance_ids')
    def _compute_avg_completion_time(self):
        """Calcule le temps moyen de finalisation"""
        for record in self:
            completed_instances = record.approval_instance_ids.filtered(
                lambda x: x.state == 'approved' and x.completion_date
            )
            if completed_instances:
                total_time = sum([
                    (instance.completion_date - instance.start_date).days
                    for instance in completed_instances
                ])
                record.avg_completion_time = total_time / len(completed_instances)
            else:
                record.avg_completion_time = 0.0
    
    @api.depends('approval_instance_ids')
    def _compute_success_rate(self):
        """Calcule le taux de réussite du workflow"""
        for record in self:
            total_instances = len(record.approval_instance_ids)
            if total_instances > 0:
                approved_instances = len(record.approval_instance_ids.filtered(
                    lambda x: x.state == 'approved'
                ))
                record.success_rate = (approved_instances / total_instances) * 100
            else:
                record.success_rate = 0.0
    
    @api.constrains('step_ids')
    def _check_workflow_steps(self):
        """Valide la configuration des étapes du workflow"""
        for record in self:
            if not record.step_ids:
                raise ValidationError(
                    _("Le workflow doit avoir au moins une étape.")
                )
            
            # Vérifier l'ordre des étapes pour les workflows séquentiels
            if record.workflow_type == 'sequential':
                sequences = record.step_ids.mapped('sequence')
                if len(sequences) != len(set(sequences)):
                    raise ValidationError(
                        _("Les étapes d'un workflow séquentiel doivent avoir des séquences uniques.")
                    )
    
    @api.model
    def create(self, vals):
        """Surcharge de create pour valider les données"""
        if 'code' in vals:
            vals['code'] = vals['code'].upper()
        return super().create(vals)
    
    def write(self, vals):
        """Surcharge de write pour valider les données"""
        if 'code' in vals:
            vals['code'] = vals['code'].upper()
        return super().write(vals)
    
    def action_view_instances(self):
        """Action pour voir les instances d'approbation"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Instances d\'Approbation - %s') % self.name,
            'res_model': 'al.approval.instance',
            'view_mode': 'tree,form,kanban',
            'domain': [('workflow_id', '=', self.id)],
            'context': {
                'default_workflow_id': self.id,
            },
        }
    
    def create_approval_instance(self, document_id):
        """Crée une nouvelle instance d'approbation pour un document"""
        if not self.active:
            raise UserError(_("Impossible de créer une instance pour un workflow inactif."))
        
        if not self.step_ids:
            raise UserError(_("Le workflow doit avoir au moins une étape."))
        
        # Créer l'instance d'approbation
        instance_vals = {
            'workflow_id': self.id,
            'document_id': document_id,
            'state': 'draft',
            'start_date': fields.Datetime.now(),
        }
        
        instance = self.env['al.approval.instance'].create(instance_vals)
        
        # Créer les étapes d'approbation
        for step in self.step_ids.sorted('sequence'):
            step_vals = {
                'instance_id': instance.id,
                'step_id': step.id,
                'approver_id': step.approver_id.id,
                'state': 'pending' if step.sequence == 1 else 'waiting',
                'timeout_date': fields.Datetime.now() + 
                               fields.timedelta(days=step.timeout_days or self.default_timeout_days),
            }
            self.env['al.approval.instance.step'].create(step_vals)
        
        # Démarrer automatiquement si configuré
        if self.auto_start:
            instance.action_start()
        
        return instance
    
    def get_next_approvers(self, current_step_sequence=0):
        """Retourne les prochains approbateurs selon le type de workflow"""
        if self.workflow_type == 'sequential':
            next_step = self.step_ids.filtered(
                lambda s: s.sequence > current_step_sequence
            ).sorted('sequence')[:1]
            return next_step.approver_id if next_step else self.env['res.users']
        
        elif self.workflow_type == 'parallel':
            # Pour les workflows parallèles, retourner tous les approbateurs restants
            return self.step_ids.mapped('approver_id')
        
        else:  # conditional
            # Pour les workflows conditionnels, la logique sera implémentée selon les besoins
            return self.env['res.users']
    
    def duplicate_workflow(self):
        """Duplique le workflow avec un nouveau nom"""
        new_name = _("%s (Copie)") % self.name
        new_code = "%s_COPY" % self.code
        
        # Vérifier l'unicité du code
        counter = 1
        while self.search([('code', '=', new_code)]):
            new_code = "%s_COPY_%d" % (self.code, counter)
            counter += 1
        
        return self.copy({
            'name': new_name,
            'code': new_code,
            'active': False,  # Désactiver la copie par défaut
        })