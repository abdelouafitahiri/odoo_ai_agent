# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ApprovalStep(models.Model):
    """Modèle d'étape d'approbation pour les étapes de workflow"""
    _name = 'al.approval.step'
    _description = 'Étape d\'Approbation'
    _order = 'workflow_id, sequence'
    
    name = fields.Char(
        string='Nom',
        required=True,
        translate=True,
        help='Nom de l\'étape d\'approbation'
    )
    
    description = fields.Text(
        string='Description',
        translate=True,
        help='Description détaillée de l\'étape'
    )
    
    sequence = fields.Integer(
        string='Séquence',
        required=True,
        help='Ordre d\'exécution de l\'étape dans le workflow'
    )
    
    active = fields.Boolean(
        string='Actif',
        default=True,
        help='Indique si l\'étape est active'
    )
    
    # Relation avec le workflow
    workflow_id = fields.Many2one(
        'al.approval.workflow',
        string='Workflow',
        required=True,
        ondelete='cascade',
        help='Workflow auquel appartient cette étape'
    )
    
    # Configuration de l'approbateur
    approver_type = fields.Selection([
        ('user', 'Utilisateur Spécifique'),
        ('group', 'Groupe d\'Utilisateurs'),
        ('role', 'Rôle'),
        ('manager', 'Manager du Demandeur'),
        ('department_head', 'Chef de Département'),
        ('dynamic', 'Dynamique')
    ], string='Type d\'Approbateur', required=True, default='user')
    
    approver_id = fields.Many2one(
        'res.users',
        string='Approbateur',
        help='Utilisateur responsable de cette étape'
    )
    
    approver_group_id = fields.Many2one(
        'res.groups',
        string='Groupe d\'Approbateurs',
        help='Groupe d\'utilisateurs pouvant approuver cette étape'
    )
    
    approver_role = fields.Char(
        string='Rôle d\'Approbateur',
        help='Rôle requis pour approuver cette étape'
    )
    
    # Configuration des conditions
    condition_type = fields.Selection([
        ('always', 'Toujours'),
        ('amount', 'Montant'),
        ('field_value', 'Valeur de Champ'),
        ('python_code', 'Code Python')
    ], string='Type de Condition', default='always')
    
    condition_amount_min = fields.Float(
        string='Montant Minimum',
        help='Montant minimum pour déclencher cette étape'
    )
    
    condition_amount_max = fields.Float(
        string='Montant Maximum',
        help='Montant maximum pour déclencher cette étape'
    )
    
    condition_field = fields.Char(
        string='Champ de Condition',
        help='Nom du champ à vérifier pour la condition'
    )
    
    condition_value = fields.Char(
        string='Valeur de Condition',
        help='Valeur attendue pour le champ de condition'
    )
    
    condition_python_code = fields.Text(
        string='Code Python',
        help='Code Python pour évaluer la condition (variable \'record\' disponible)'
    )
    
    # Configuration des délais
    timeout_days = fields.Integer(
        string='Délai (jours)',
        help='Délai spécifique pour cette étape (sinon utilise le délai par défaut du workflow)'
    )
    
    reminder_days = fields.Integer(
        string='Rappel (jours)',
        default=1,
        help='Nombre de jours avant le délai pour envoyer un rappel'
    )
    
    # Configuration des actions
    auto_approve = fields.Boolean(
        string='Approbation Automatique',
        default=False,
        help='Approuve automatiquement cette étape si les conditions sont remplies'
    )
    
    auto_approve_condition = fields.Text(
        string='Condition d\'Approbation Automatique',
        help='Code Python pour l\'approbation automatique'
    )
    
    can_delegate = fields.Boolean(
        string='Peut Déléguer',
        default=True,
        help='L\'approbateur peut déléguer cette étape à un autre utilisateur'
    )
    
    can_reject = fields.Boolean(
        string='Peut Rejeter',
        default=True,
        help='L\'approbateur peut rejeter à cette étape'
    )
    
    rejection_returns_to = fields.Selection([
        ('start', 'Début du Workflow'),
        ('previous', 'Étape Précédente'),
        ('specific', 'Étape Spécifique'),
        ('end', 'Fin du Workflow')
    ], string='Rejet Retourne à', default='start')
    
    rejection_target_step_id = fields.Many2one(
        'al.approval.step',
        string='Étape Cible de Rejet',
        help='Étape vers laquelle retourner en cas de rejet'
    )
    
    # Configuration des notifications
    notify_on_pending = fields.Boolean(
        string='Notifier en Attente',
        default=True,
        help='Envoie une notification quand l\'étape devient en attente'
    )
    
    notify_on_reminder = fields.Boolean(
        string='Notifier les Rappels',
        default=True,
        help='Envoie des notifications de rappel'
    )
    
    notification_template_id = fields.Many2one(
        'mail.template',
        string='Modèle de Notification',
        help='Modèle d\'email pour les notifications de cette étape'
    )
    
    # Statistiques
    avg_processing_time = fields.Float(
        string='Temps Moyen de Traitement (heures)',
        compute='_compute_avg_processing_time',
        help='Temps moyen de traitement de cette étape'
    )
    
    approval_rate = fields.Float(
        string='Taux d\'Approbation (%)',
        compute='_compute_approval_rate',
        help='Pourcentage d\'approbations pour cette étape'
    )
    
    # Relations
    instance_step_ids = fields.One2many(
        'al.approval.instance.step',
        'step_id',
        string='Instances d\'Étapes',
        help='Instances de cette étape dans les workflows'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('sequence_positive', 'check(sequence > 0)', 
         'La séquence doit être positive.'),
        ('timeout_positive', 'check(timeout_days IS NULL OR timeout_days > 0)', 
         'Le délai doit être positif.'),
        ('reminder_positive', 'check(reminder_days >= 0)', 
         'Le délai de rappel doit être positif ou nul.'),
        ('amount_min_max', 'check(condition_amount_min IS NULL OR condition_amount_max IS NULL OR condition_amount_min <= condition_amount_max)', 
         'Le montant minimum doit être inférieur ou égal au montant maximum.')
    ]
    
    @api.depends('instance_step_ids')
    def _compute_avg_processing_time(self):
        """Calcule le temps moyen de traitement de l'étape"""
        for record in self:
            completed_steps = record.instance_step_ids.filtered(
                lambda x: x.state in ['approved', 'rejected'] and x.completion_date and x.start_date
            )
            if completed_steps:
                total_time = sum([
                    (step.completion_date - step.start_date).total_seconds() / 3600
                    for step in completed_steps
                ])
                record.avg_processing_time = total_time / len(completed_steps)
            else:
                record.avg_processing_time = 0.0
    
    @api.depends('instance_step_ids')
    def _compute_approval_rate(self):
        """Calcule le taux d'approbation de l'étape"""
        for record in self:
            total_steps = len(record.instance_step_ids.filtered(
                lambda x: x.state in ['approved', 'rejected']
            ))
            if total_steps > 0:
                approved_steps = len(record.instance_step_ids.filtered(
                    lambda x: x.state == 'approved'
                ))
                record.approval_rate = (approved_steps / total_steps) * 100
            else:
                record.approval_rate = 0.0
    
    @api.constrains('approver_type', 'approver_id', 'approver_group_id')
    def _check_approver_configuration(self):
        """Valide la configuration de l'approbateur"""
        for record in self:
            if record.approver_type == 'user' and not record.approver_id:
                raise ValidationError(
                    _("Un utilisateur approbateur doit être spécifié pour le type 'Utilisateur Spécifique'.")
                )
            elif record.approver_type == 'group' and not record.approver_group_id:
                raise ValidationError(
                    _("Un groupe d'approbateurs doit être spécifié pour le type 'Groupe d'Utilisateurs'.")
                )
            elif record.approver_type == 'role' and not record.approver_role:
                raise ValidationError(
                    _("Un rôle d'approbateur doit être spécifié pour le type 'Rôle'.")
                )
    
    @api.constrains('condition_type', 'condition_python_code')
    def _check_condition_configuration(self):
        """Valide la configuration des conditions"""
        for record in self:
            if record.condition_type == 'python_code' and not record.condition_python_code:
                raise ValidationError(
                    _("Le code Python doit être spécifié pour le type de condition 'Code Python'.")
                )
    
    @api.constrains('rejection_returns_to', 'rejection_target_step_id')
    def _check_rejection_configuration(self):
        """Valide la configuration du rejet"""
        for record in self:
            if record.rejection_returns_to == 'specific' and not record.rejection_target_step_id:
                raise ValidationError(
                    _("Une étape cible doit être spécifiée pour le rejet vers une 'Étape Spécifique'.")
                )
            elif record.rejection_returns_to == 'specific' and record.rejection_target_step_id.workflow_id != record.workflow_id:
                raise ValidationError(
                    _("L'étape cible de rejet doit appartenir au même workflow.")
                )
    
    def get_approvers(self, document=None):
        """Retourne la liste des approbateurs pour cette étape"""
        approvers = self.env['res.users']
        
        if self.approver_type == 'user':
            approvers = self.approver_id
        elif self.approver_type == 'group':
            approvers = self.approver_group_id.users
        elif self.approver_type == 'manager' and document:
            # Logique pour trouver le manager du demandeur
            if hasattr(document, 'create_uid') and document.create_uid.parent_id:
                approvers = document.create_uid.parent_id
        elif self.approver_type == 'department_head' and document:
            # Logique pour trouver le chef de département
            if hasattr(document, 'create_uid') and document.create_uid.department_id:
                approvers = document.create_uid.department_id.manager_id
        
        return approvers
    
    def evaluate_condition(self, document):
        """Évalue si la condition de l'étape est remplie"""
        if self.condition_type == 'always':
            return True
        elif self.condition_type == 'amount' and hasattr(document, 'amount'):
            amount = document.amount or 0
            min_ok = not self.condition_amount_min or amount >= self.condition_amount_min
            max_ok = not self.condition_amount_max or amount <= self.condition_amount_max
            return min_ok and max_ok
        elif self.condition_type == 'field_value' and self.condition_field:
            field_value = getattr(document, self.condition_field, None)
            return str(field_value) == str(self.condition_value)
        elif self.condition_type == 'python_code' and self.condition_python_code:
            try:
                # Contexte sécurisé pour l'évaluation du code Python
                safe_globals = {
                    '__builtins__': {},
                    'record': document,
                    'env': self.env,
                    'user': self.env.user,
                }
                return bool(eval(self.condition_python_code, safe_globals))
            except Exception:
                return False
        
        return False
    
    def should_auto_approve(self, document):
        """Vérifie si l'étape doit être approuvée automatiquement"""
        if not self.auto_approve:
            return False
        
        if not self.auto_approve_condition:
            return True
        
        try:
            safe_globals = {
                '__builtins__': {},
                'record': document,
                'env': self.env,
                'user': self.env.user,
            }
            return bool(eval(self.auto_approve_condition, safe_globals))
        except Exception:
            return False