# -*- coding: utf-8 -*-

from odoo import models, fields, api


class OutgoingMail(models.Model):
    """Model for managing outgoing mail documents"""
    _name = 'al.outgoing.mail'
    _description = 'Outgoing Mail Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'send_date desc'
    
    # Fields will be defined here
    
    # Methods will be implemented here
    pass