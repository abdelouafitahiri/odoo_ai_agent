# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError
from datetime import datetime, timedelta


class ApprovalInstanceStep(models.Model):
    """Modèle d'étape d'instance d'approbation pour suivre chaque étape individuellement"""
    _name = 'al.approval.instance.step'
    _description = 'Étape d\'Instance d\'Approbation'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'instance_id, step_id'
    
    # Relations principales
    instance_id = fields.Many2one(
        'al.approval.instance',
        string='Instance d\'Approbation',
        required=True,
        ondelete='cascade',
        help='Instance d\'approbation parente'
    )
    
    step_id = fields.Many2one(
        'al.approval.step',
        string='Étape',
        required=True,
        help='Définition de l\'étape'
    )
    
    # Informations de base
    name = fields.Char(
        string='Nom',
        related='step_id.name',
        readonly=True,
        help='Nom de l\'étape'
    )
    
    sequence = fields.Integer(
        string='Séquence',
        related='step_id.sequence',
        readonly=True,
        help='Ordre de l\'étape'
    )
    
    # État et progression
    state = fields.Selection([
        ('waiting', 'En Attente'),
        ('pending', 'En Cours'),
        ('approved', 'Approuvé'),
        ('rejected', 'Rejeté'),
        ('cancelled', 'Annulé'),
        ('delegated', 'Délégué'),
        ('expired', 'Expiré')
    ], string='État', default='waiting', tracking=True, required=True)
    
    # Approbateur assigné
    approver_id = fields.Many2one(
        'res.users',
        string='Approbateur',
        help='Utilisateur responsable de cette étape'
    )
    
    original_approver_id = fields.Many2one(
        'res.users',
        string='Approbateur Original',
        help='Approbateur original avant délégation'
    )
    
    delegated_by_id = fields.Many2one(
        'res.users',
        string='Délégué par',
        help='Utilisateur qui a délégué cette étape'
    )
    
    # Dates importantes
    start_date = fields.Datetime(
        string='Date de Début',
        help='Date de début de traitement de cette étape'
    )
    
    completion_date = fields.Datetime(
        string='Date de Finalisation',
        help='Date de finalisation de cette étape'
    )
    
    timeout_date = fields.Datetime(
        string='Date Limite',
        help='Date limite pour cette étape'
    )
    
    reminder_date = fields.Datetime(
        string='Date de Rappel',
        compute='_compute_reminder_date',
        help='Date pour envoyer un rappel'
    )
    
    # Commentaires et justifications
    approver_comment = fields.Text(
        string='Commentaire de l\'Approbateur',
        help='Commentaire de l\'approbateur'
    )
    
    rejection_reason = fields.Text(
        string='Raison du Rejet',
        help='Raison détaillée du rejet'
    )
    
    delegation_reason = fields.Text(
        string='Raison de la Délégation',
        help='Raison de la délégation'
    )
    
    # Métriques
    processing_time = fields.Float(
        string='Temps de Traitement (heures)',
        compute='_compute_processing_time',
        help='Temps de traitement de cette étape en heures'
    )
    
    is_overdue = fields.Boolean(
        string='En Retard',
        compute='_compute_is_overdue',
        help='Indique si l\'étape est en retard'
    )
    
    days_remaining = fields.Integer(
        string='Jours Restants',
        compute='_compute_days_remaining',
        help='Nombre de jours restants avant expiration'
    )
    
    # Configuration dynamique
    can_approve = fields.Boolean(
        string='Peut Approuver',
        compute='_compute_can_approve',
        help='Indique si l\'utilisateur actuel peut approuver'
    )
    
    can_reject = fields.Boolean(
        string='Peut Rejeter',
        compute='_compute_can_reject',
        help='Indique si l\'utilisateur actuel peut rejeter'
    )
    
    can_delegate = fields.Boolean(
        string='Peut Déléguer',
        compute='_compute_can_delegate',
        help='Indique si l\'utilisateur actuel peut déléguer'
    )
    
    # Relations
    document_id = fields.Many2one(
        'documents.document',
        related='instance_id.document_id',
        readonly=True,
        help='Document en cours d\'approbation'
    )
    
    workflow_id = fields.Many2one(
        'al.approval.workflow',
        related='instance_id.workflow_id',
        readonly=True,
        help='Workflow d\'approbation'
    )
    
    @api.depends('timeout_date', 'step_id.reminder_days')
    def _compute_reminder_date(self):
        """Calcule la date de rappel"""
        for record in self:
            if record.timeout_date and record.step_id.reminder_days:
                record.reminder_date = record.timeout_date - timedelta(days=record.step_id.reminder_days)
            else:
                record.reminder_date = False
    
    @api.depends('start_date', 'completion_date')
    def _compute_processing_time(self):
        """Calcule le temps de traitement"""
        for record in self:
            if record.start_date:
                end_date = record.completion_date or fields.Datetime.now()
                delta = end_date - record.start_date
                record.processing_time = delta.total_seconds() / 3600
            else:
                record.processing_time = 0.0
    
    @api.depends('timeout_date', 'state')
    def _compute_is_overdue(self):
        """Détermine si l'étape est en retard"""
        for record in self:
            record.is_overdue = (
                record.state == 'pending' and
                record.timeout_date and
                record.timeout_date < fields.Datetime.now()
            )
    
    @api.depends('timeout_date')
    def _compute_days_remaining(self):
        """Calcule les jours restants"""
        for record in self:
            if record.timeout_date and record.state == 'pending':
                delta = record.timeout_date - fields.Datetime.now()
                record.days_remaining = delta.days
            else:
                record.days_remaining = 0
    
    @api.depends('approver_id', 'state')
    def _compute_can_approve(self):
        """Détermine si l'utilisateur peut approuver"""
        for record in self:
            record.can_approve = (
                record.state == 'pending' and
                record.approver_id == self.env.user
            )
    
    @api.depends('approver_id', 'state', 'step_id.can_reject')
    def _compute_can_reject(self):
        """Détermine si l'utilisateur peut rejeter"""
        for record in self:
            record.can_reject = (
                record.state == 'pending' and
                record.approver_id == self.env.user and
                record.step_id.can_reject
            )
    
    @api.depends('approver_id', 'state', 'step_id.can_delegate')
    def _compute_can_delegate(self):
        """Détermine si l'utilisateur peut déléguer"""
        for record in self:
            record.can_delegate = (
                record.state == 'pending' and
                record.approver_id == self.env.user and
                record.step_id.can_delegate
            )
    
    def action_activate(self):
        """Active cette étape (la met en cours)"""
        if self.state != 'waiting':
            raise UserError(_("Seules les étapes en attente peuvent être activées."))
        
        # Vérifier les conditions de l'étape
        if not self.step_id.evaluate_condition(self.document_id):
            # Si la condition n'est pas remplie, passer à l'étape suivante
            self.write({'state': 'cancelled'})
            return self._activate_next_step()
        
        # Vérifier l'approbation automatique
        if self.step_id.should_auto_approve(self.document_id):
            return self.action_auto_approve()
        
        # Activer l'étape
        self.write({
            'state': 'pending',
            'start_date': fields.Datetime.now(),
        })
        
        # Envoyer les notifications
        if self.step_id.notify_on_pending:
            self._send_notification('pending')
        
        # Créer une activité pour l'approbateur
        self._create_approval_activity()
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'étape '%s' a été activée et assignée à %s.") % 
                 (self.name, self.approver_id.name),
            message_type='notification'
        )
        
        return True
    
    def action_approve(self, comment=None):
        """Approuve cette étape"""
        if not self.can_approve:
            raise UserError(_("Vous n'êtes pas autorisé à approuver cette étape."))
        
        # Marquer comme approuvé
        self.write({
            'state': 'approved',
            'completion_date': fields.Datetime.now(),
            'approver_comment': comment or '',
        })
        
        # Fermer l'activité en cours
        self._close_approval_activity()
        
        # Envoyer les notifications
        if self.workflow_id.notify_on_approval:
            self._send_notification('approved')
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'étape '%s' a été approuvée par %s. %s") % 
                 (self.name, self.env.user.name, comment or ''),
            message_type='notification'
        )
        
        # Activer l'étape suivante ou finaliser
        return self._activate_next_step()
    
    def action_reject(self, reason=None):
        """Rejette cette étape"""
        if not self.can_reject:
            raise UserError(_("Vous n'êtes pas autorisé à rejeter cette étape."))
        
        # Marquer comme rejeté
        self.write({
            'state': 'rejected',
            'completion_date': fields.Datetime.now(),
            'rejection_reason': reason or '',
        })
        
        # Fermer l'activité en cours
        self._close_approval_activity()
        
        # Envoyer les notifications
        if self.workflow_id.notify_on_rejection:
            self._send_notification('rejected')
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'étape '%s' a été rejetée par %s. %s") % 
                 (self.name, self.env.user.name, reason or ''),
            message_type='notification'
        )
        
        # Gérer le rejet selon la configuration
        return self._handle_rejection()
    
    def action_delegate(self, new_approver_id, reason=None):
        """Délègue cette étape à un autre utilisateur"""
        if not self.can_delegate:
            raise UserError(_("Vous n'êtes pas autorisé à déléguer cette étape."))
        
        if not new_approver_id:
            raise UserError(_("Un nouvel approbateur doit être spécifié."))
        
        new_approver = self.env['res.users'].browse(new_approver_id)
        
        # Sauvegarder l'approbateur original
        if not self.original_approver_id:
            self.original_approver_id = self.approver_id
        
        # Déléguer
        self.write({
            'state': 'delegated',
            'approver_id': new_approver_id,
            'delegated_by_id': self.env.user.id,
            'delegation_reason': reason or '',
        })
        
        # Fermer l'activité actuelle et en créer une nouvelle
        self._close_approval_activity()
        self._create_approval_activity()
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'étape '%s' a été déléguée de %s à %s. %s") % 
                 (self.name, self.env.user.name, new_approver.name, reason or ''),
            message_type='notification'
        )
        
        # Remettre en cours
        self.write({'state': 'pending'})
        
        return True
    
    def action_auto_approve(self):
        """Approuve automatiquement cette étape"""
        self.write({
            'state': 'approved',
            'completion_date': fields.Datetime.now(),
            'approver_comment': _('Approbation automatique'),
        })
        
        # Enregistrer dans le chatter
        self.message_post(
            body=_("L'étape '%s' a été approuvée automatiquement.") % self.name,
            message_type='notification'
        )
        
        # Activer l'étape suivante
        return self._activate_next_step()
    
    def _activate_next_step(self):
        """Active la prochaine étape selon le type de workflow"""
        if self.workflow_id.workflow_type == 'sequential':
            # Workflow séquentiel : activer l'étape suivante
            next_step = self.instance_id.step_instance_ids.filtered(
                lambda x: x.step_id.sequence > self.step_id.sequence and x.state == 'waiting'
            ).sorted('step_id.sequence')[:1]
            
            if next_step:
                return next_step.action_activate()
            else:
                # Plus d'étapes : finaliser l'instance
                return self.instance_id.action_approve()
        
        elif self.workflow_id.workflow_type == 'parallel':
            # Workflow parallèle : vérifier si toutes les étapes sont terminées
            remaining_steps = self.instance_id.step_instance_ids.filtered(
                lambda x: x.state in ['waiting', 'pending']
            )
            
            if not remaining_steps:
                # Toutes les étapes sont terminées
                rejected_steps = self.instance_id.step_instance_ids.filtered(
                    lambda x: x.state == 'rejected'
                )
                
                if rejected_steps:
                    return self.instance_id.action_reject()
                else:
                    return self.instance_id.action_approve()
        
        return True
    
    def _handle_rejection(self):
        """Gère le rejet selon la configuration de l'étape"""
        if self.step_id.rejection_returns_to == 'end':
            # Rejeter toute l'instance
            return self.instance_id.action_reject(self.rejection_reason)
        
        elif self.step_id.rejection_returns_to == 'start':
            # Retourner au début : remettre toutes les étapes en attente
            self.instance_id.step_instance_ids.write({'state': 'waiting'})
            first_step = self.instance_id.step_instance_ids.sorted('step_id.sequence')[0]
            return first_step.action_activate()
        
        elif self.step_id.rejection_returns_to == 'previous':
            # Retourner à l'étape précédente
            previous_step = self.instance_id.step_instance_ids.filtered(
                lambda x: x.step_id.sequence < self.step_id.sequence
            ).sorted('step_id.sequence', reverse=True)[:1]
            
            if previous_step:
                previous_step.write({'state': 'waiting'})
                return previous_step.action_activate()
            else:
                return self.instance_id.action_reject(self.rejection_reason)
        
        elif self.step_id.rejection_returns_to == 'specific' and self.step_id.rejection_target_step_id:
            # Retourner à une étape spécifique
            target_step = self.instance_id.step_instance_ids.filtered(
                lambda x: x.step_id == self.step_id.rejection_target_step_id
            )
            
            if target_step:
                target_step.write({'state': 'waiting'})
                return target_step.action_activate()
        
        # Par défaut, rejeter l'instance
        return self.instance_id.action_reject(self.rejection_reason)
    
    def _create_approval_activity(self):
        """Crée une activité pour l'approbateur"""
        if self.approver_id:
            self.activity_schedule(
                'mail.mail_activity_data_todo',
                user_id=self.approver_id.id,
                summary=_("Approbation requise : %s") % self.document_id.name,
                note=_("Veuillez approuver ou rejeter l'étape '%s' pour le document '%s'.") % 
                     (self.name, self.document_id.name),
                date_deadline=self.timeout_date.date() if self.timeout_date else fields.Date.today()
            )
    
    def _close_approval_activity(self):
        """Ferme l'activité d'approbation en cours"""
        activities = self.activity_ids.filtered(
            lambda a: a.activity_type_id.id == self.env.ref('mail.mail_activity_data_todo').id
        )
        activities.action_done()
    
    def _send_notification(self, notification_type):
        """Envoie une notification selon le type"""
        # Logique de notification à implémenter
        pass
    
    @api.model
    def cron_check_timeouts(self):
        """Tâche cron pour vérifier les délais dépassés"""
        overdue_steps = self.search([
            ('state', '=', 'pending'),
            ('timeout_date', '!=', False),
            ('timeout_date', '<', fields.Datetime.now())
        ])
        
        for step in overdue_steps:
            step.write({'state': 'expired'})
            
            # Gérer l'escalade si configurée
            if step.workflow_id.escalation_enabled:
                step._handle_escalation()
        
        return len(overdue_steps)
    
    def _handle_escalation(self):
        """Gère l'escalade en cas de dépassement de délai"""
        # Logique d'escalade à implémenter selon les besoins
        pass