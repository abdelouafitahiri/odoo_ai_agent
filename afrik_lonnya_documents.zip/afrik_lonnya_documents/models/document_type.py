# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class DocumentType(models.Model):
    """Modèle de type de document pour catégoriser les documents"""
    _name = 'al.document.type'
    _description = 'Type de Document'
    _order = 'sequence, name'
    
    name = fields.Char(
        string='Nom',
        required=True,
        translate=True,
        help='Nom du type de document'
    )
    
    code = fields.Char(
        string='Code',
        required=True,
        help='Code unique pour identifier le type de document'
    )
    
    description = fields.Text(
        string='Description',
        translate=True,
        help='Description détaillée du type de document'
    )
    
    sequence = fields.Integer(
        string='Séquence',
        default=10,
        help='Ordre d\'affichage du type de document'
    )
    
    active = fields.Boolean(
        string='Actif',
        default=True,
        help='Indique si le type de document est actif'
    )
    
    # Catégorisation
    category = fields.Selection([
        ('administrative', 'Administratif'),
        ('financial', 'Financier'),
        ('legal', 'Juridique'),
        ('technical', 'Technique'),
        ('commercial', 'Commercial'),
        ('hr', 'Ressources Humaines'),
        ('other', 'Autre')
    ], string='Catégorie', required=True, default='other')
    
    # Configuration du workflow
    requires_approval = fields.Boolean(
        string='Nécessite une Approbation',
        default=False,
        help='Indique si les documents de ce type nécessitent une approbation'
    )
    
    approval_workflow_id = fields.Many2one(
        'al.approval.workflow',
        string='Workflow d\'Approbation',
        help='Workflow d\'approbation à utiliser pour ce type de document'
    )
    
    # Configuration de l'archivage
    retention_period = fields.Integer(
        string='Période de Rétention (mois)',
        default=12,
        help='Période de rétention en mois avant archivage automatique'
    )
    
    auto_archive = fields.Boolean(
        string='Archivage Automatique',
        default=False,
        help='Active l\'archivage automatique après la période de rétention'
    )
    
    # Configuration des métadonnées
    mandatory_fields = fields.Text(
        string='Champs Obligatoires',
        help='Liste des champs obligatoires pour ce type de document (JSON)'
    )
    
    allowed_extensions = fields.Char(
        string='Extensions Autorisées',
        help='Extensions de fichiers autorisées (séparées par des virgules)'
    )
    
    max_file_size = fields.Float(
        string='Taille Maximale (MB)',
        default=10.0,
        help='Taille maximale autorisée pour les fichiers de ce type'
    )
    
    # Configuration de sécurité
    default_classification = fields.Selection([
        ('public', 'Public'),
        ('internal', 'Interne'),
        ('confidential', 'Confidentiel'),
        ('secret', 'Secret')
    ], string='Classification par Défaut', default='internal')
    
    access_group_ids = fields.Many2many(
        'res.groups',
        string='Groupes d\'Accès',
        help='Groupes ayant accès aux documents de ce type'
    )
    
    # Statistiques
    document_count = fields.Integer(
        string='Nombre de Documents',
        compute='_compute_document_count',
        help='Nombre total de documents de ce type'
    )
    
    # Relations
    document_ids = fields.One2many(
        'documents.document',
        'document_type_id',
        string='Documents',
        help='Documents associés à ce type'
    )
    
    # Contraintes SQL
    _sql_constraints = [
        ('code_unique', 'unique(code)', 'Le code du type de document doit être unique.'),
        ('name_unique', 'unique(name)', 'Le nom du type de document doit être unique.'),
        ('retention_period_positive', 'check(retention_period > 0)', 
         'La période de rétention doit être positive.'),
        ('max_file_size_positive', 'check(max_file_size > 0)', 
         'La taille maximale du fichier doit être positive.')
    ]
    
    @api.depends('document_ids')
    def _compute_document_count(self):
        """Calcule le nombre de documents pour chaque type"""
        for record in self:
            record.document_count = len(record.document_ids)
    
    @api.constrains('allowed_extensions')
    def _check_allowed_extensions(self):
        """Valide le format des extensions autorisées"""
        for record in self:
            if record.allowed_extensions:
                extensions = [ext.strip() for ext in record.allowed_extensions.split(',')]
                for ext in extensions:
                    if not ext.startswith('.'):
                        raise ValidationError(
                            _("Les extensions doivent commencer par un point (ex: .pdf, .doc)")
                        )
    
    @api.model
    def create(self, vals):
        """Surcharge de create pour valider les données"""
        if 'code' in vals:
            vals['code'] = vals['code'].upper()
        return super().create(vals)
    
    def write(self, vals):
        """Surcharge de write pour valider les données"""
        if 'code' in vals:
            vals['code'] = vals['code'].upper()
        return super().write(vals)
    
    def action_view_documents(self):
        """Action pour voir les documents de ce type"""
        return {
            'type': 'ir.actions.act_window',
            'name': _('Documents - %s') % self.name,
            'res_model': 'documents.document',
            'view_mode': 'kanban,tree,form',
            'domain': [('document_type_id', '=', self.id)],
            'context': {
                'default_document_type_id': self.id,
                'search_default_document_type_id': self.id,
            },
        }
    
    def get_mandatory_fields_list(self):
        """Retourne la liste des champs obligatoires"""
        if self.mandatory_fields:
            try:
                import json
                return json.loads(self.mandatory_fields)
            except (ValueError, TypeError):
                return []
        return []
    
    def validate_document_fields(self, document_vals):
        """Valide que les champs obligatoires sont remplis pour un document"""
        mandatory_fields = self.get_mandatory_fields_list()
        missing_fields = []
        
        for field in mandatory_fields:
            if field not in document_vals or not document_vals[field]:
                missing_fields.append(field)
        
        if missing_fields:
            raise ValidationError(
                _("Les champs suivants sont obligatoires pour le type '%s': %s") % 
                (self.name, ', '.join(missing_fields))
            )
        
        return True