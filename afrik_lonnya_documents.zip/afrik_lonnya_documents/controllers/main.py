# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request


class AfrikLonnyaDocumentsController(http.Controller):
    """Main controller for Afrik Lonnya Documents module"""
    
    # Routes and methods will be implemented here
    pass