# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal


class AfrikLonnyaDocumentsPortal(CustomerPortal):
    """Portal controller for Afrik Lonnya Documents module"""
    
    # Portal routes and methods will be implemented here
    pass