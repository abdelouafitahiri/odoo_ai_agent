# -*- coding: utf-8 -*-

from odoo import models, fields, api


class DocumentApprovalWizard(models.TransientModel):
    """Wizard for document approval process"""
    _name = 'afrik.lonnya.document.approval.wizard'
    _description = 'Document Approval Wizard'
    
    # Fields will be defined here
    
    # Methods will be implemented here
    pass