# -*- coding: utf-8 -*-

from odoo import models, fields, api


class MailProcessingWizard(models.TransientModel):
    """Wizard for mail processing (incoming/outgoing)"""
    _name = 'afrik.lonnya.mail.processing.wizard'
    _description = 'Mail Processing Wizard'
    
    # Fields will be defined here
    
    # Methods will be implemented here
    pass