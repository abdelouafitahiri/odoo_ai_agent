# -*- coding: utf-8 -*-

from . import document_approval_wizard
from . import mail_processing_wizard