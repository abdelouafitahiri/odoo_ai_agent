# -*- coding: utf-8 -*-
{
    'name': 'Afrik Lonnya Documents - GED Module',
    'version': '18.0.1.0.0',
    'category': 'Productivity/Documents',
    'summary': 'Electronic Document Management System for Afrik Lonnya SA',
    'description': """
        Extension of Odoo Documents module with advanced features:
        - Incoming/Outgoing mail management
        - Contract and agreement management
        - Electronic archiving with approval workflows
        - Document lifecycle management
        - Integration with all business processes
    """,
    'author': 'Afrik Lonnya SA',
    'website': 'https://www.afriklonnya.com',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'documents',
        'mail',
        'portal',
        'web',
        'project',
        'sale',
        'purchase',
        'account',
        'hr',
        'fleet',
    ],
    'data': [
        # Security
        'security/security.xml',
        'security/ir.model.access.csv',
        
        # Data
        'data/document_types_data.xml',
        'data/mail_templates_data.xml',
        'data/workflow_data.xml',
        
        # Views
        'views/document_views.xml',
        'views/incoming_mail_views.xml',
        'views/outgoing_mail_views.xml',
        'views/contract_views.xml',
        'views/approval_workflow_views.xml',
        'views/menu_views.xml',
        
        # Wizards
        'wizard/document_approval_wizard_views.xml',
        'wizard/mail_processing_wizard_views.xml',
    ],
    'demo': [
        'demo/demo_data.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'afrik_lonnya_documents/static/src/js/**/*',
            'afrik_lonnya_documents/static/src/css/**/*',
        ],
    },
    'installable': True,
    'auto_install': False,
    'application': True,
    'sequence': 10,
}